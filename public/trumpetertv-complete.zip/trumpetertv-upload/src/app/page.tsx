'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useData } from '@/contexts/DataContext'
import Logo from '@/components/Logo'

export default function HomePage() {
  const { settings, slides, loading } = useData()
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    if (slides.length <= 1) return
    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length)
    }, settings?.slider_interval || 6000)
    return () => clearInterval(interval)
  }, [slides.length, settings?.slider_interval])

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="h-screen w-screen overflow-hidden relative">
      {/* Full Screen Slider */}
      {slides.length > 0 && (
        <div className="absolute inset-0">
          {slides.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${slide.imageUrl})` }}
              />
              <div className="absolute inset-0 bg-black/40" />
            </div>
          ))}
        </div>
      )}

      {/* Logo */}
      <div className="absolute top-6 left-6 z-30">
        <Logo size="md" variant="light" />
      </div>

      {/* Menu Button */}
      <button
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className="absolute top-6 right-6 z-30 p-3 bg-white/20 hover:bg-white/30 rounded-full backdrop-blur-sm"
      >
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>

      {/* Center - Action Buttons */}
      <div className="absolute inset-0 flex items-center justify-center z-20">
        <div className="flex flex-col items-center gap-4">
          {/* Watch Live Button */}
          <Link
            href="/live"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-full text-lg font-bold animate-pulse"
            style={{ 
              backgroundColor: '#DC2626', 
              color: '#FFFFFF'
            }}
          >
            <span style={{ 
              width: '12px', 
              height: '12px', 
              backgroundColor: '#FFFFFF', 
              borderRadius: '50%' 
            }}></span>
            <span style={{ color: '#FFFFFF' }}>WATCH LIVE</span>
          </Link>
          
          {/* Learn Button */}
          <Link
            href="/learn"
            className="inline-flex items-center gap-2 px-8 py-3 rounded-full text-base font-semibold bg-white/90 text-gray-900 hover:bg-white transition-colors"
          >
            <span>💎</span>
            <span>Start Learning</span>
          </Link>
        </div>
      </div>

      {/* Slider Dots */}
      {slides.length > 1 && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 z-30 flex gap-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white w-8' : 'bg-white/50 hover:bg-white/75'
              }`}
            />
          ))}
        </div>
      )}

      {/* Side Menu */}
      {isMenuOpen && (
        <>
          <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setIsMenuOpen(false)} />
          <div className="fixed top-0 right-0 h-full w-72 bg-white shadow-2xl z-50 overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Menu</h2>
                <button onClick={() => setIsMenuOpen(false)} className="p-2">✕</button>
              </div>
              <nav className="space-y-2">
                <Link href="/" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Home</Link>
                <Link href="/live" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg font-semibold text-red-600">
                  🔴 Live TV
                </Link>
                <Link href="/learn" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg font-semibold text-blue-600">
                  💎 PreciousMinds
                </Link>
                <Link href="/watch" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">All Videos</Link>
                <Link href="/music" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Music</Link>
                <Link href="/community" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Community</Link>
                <Link href="/quiz" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Bible Quiz</Link>
                <div className="border-t my-4"></div>
                <Link href="/admin/dashboard" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg text-gray-500">Admin</Link>
              </nav>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
