'use client'

import { useState } from 'react'
import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Brain, Trophy, RotateCcw } from 'lucide-react'

const quizQuestions = [
  {
    id: 1,
    question: "Who built the ark?",
    options: ["Moses", "Noah", "Abraham", "David"],
    correct: 1
  },
  {
    id: 2,
    question: "How many days did God take to create the world?",
    options: ["5", "6", "7", "8"],
    correct: 1
  },
  {
    id: 3,
    question: "Who was swallowed by a great fish?",
    options: ["Jonah", "Peter", "Paul", "John"],
    correct: 0
  },
  {
    id: 4,
    question: "What is the first book of the Bible?",
    options: ["Exodus", "Psalms", "Genesis", "Matthew"],
    correct: 2
  },
  {
    id: 5,
    question: "Who killed Goliath?",
    options: ["Saul", "David", "Samuel", "Solomon"],
    correct: 1
  }
]

export default function QuizPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [showResult, setShowResult] = useState(false)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [isAnswered, setIsAnswered] = useState(false)

  const handleAnswer = (index: number) => {
    if (isAnswered) return
    
    setSelectedAnswer(index)
    setIsAnswered(true)
    
    if (index === quizQuestions[currentQuestion].correct) {
      setScore(score + 1)
    }
  }

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setIsAnswered(false)
    } else {
      setShowResult(true)
    }
  }

  const restartQuiz = () => {
    setCurrentQuestion(0)
    setScore(0)
    setShowResult(false)
    setSelectedAnswer(null)
    setIsAnswered(false)
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30 bg-gray-900/95 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="light" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-8 px-4">
        <div className="container mx-auto max-w-2xl">
          <h1 className="text-3xl font-bold text-white mb-6 flex items-center gap-3">
            <Brain className="w-8 h-8 text-purple-400" />
            Bible Quiz
          </h1>

          {showResult ? (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-8 text-center">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
                <h2 className="text-2xl font-bold text-white mb-2">Quiz Complete!</h2>
                <p className="text-gray-400 mb-4">You scored</p>
                <p className="text-5xl font-bold text-white mb-6">
                  {score} / {quizQuestions.length}
                </p>
                <p className="text-gray-400 mb-6">
                  {score === quizQuestions.length 
                    ? "Perfect! You're a Bible expert!" 
                    : score >= quizQuestions.length / 2 
                      ? "Great job! Keep studying the Word!" 
                      : "Keep learning! The Word is a lamp to your feet."}
                </p>
                <Button onClick={restartQuiz} className="bg-blue-600 hover:bg-blue-700">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Play Again
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>Question {currentQuestion + 1} of {quizQuestions.length}</span>
                  <span>Score: {score}</span>
                </div>
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-full bg-blue-500 rounded-full transition-all"
                    style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-xl">
                    {quizQuestions[currentQuestion].question}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {quizQuestions[currentQuestion].options.map((option, index) => {
                      let buttonClass = "w-full p-4 text-left rounded-lg transition-colors "
                      
                      if (isAnswered) {
                        if (index === quizQuestions[currentQuestion].correct) {
                          buttonClass += "bg-green-600 text-white"
                        } else if (index === selectedAnswer) {
                          buttonClass += "bg-red-600 text-white"
                        } else {
                          buttonClass += "bg-gray-700 text-gray-400"
                        }
                      } else {
                        buttonClass += "bg-gray-700 text-white hover:bg-gray-600"
                      }

                      return (
                        <button
                          key={index}
                          onClick={() => handleAnswer(index)}
                          className={buttonClass}
                          disabled={isAnswered}
                        >
                          {option}
                        </button>
                      )
                    })}
                  </div>

                  {isAnswered && (
                    <Button 
                      onClick={nextQuestion} 
                      className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
                    >
                      {currentQuestion < quizQuestions.length - 1 ? "Next Question" : "See Results"}
                    </Button>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  )
}
