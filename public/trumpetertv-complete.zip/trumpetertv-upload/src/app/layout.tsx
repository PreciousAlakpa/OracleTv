import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { DataProvider } from "@/contexts/DataContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "TRUMPETER TV - 24/7 Christian Broadcasting & Learning",
  description: "Watch live services, learn with PreciousMinds interactive courses, and grow in faith with TRUMPETER TV",
  keywords: ["TRUMPETER", "TV", "Church", "Live", "Learning", "PreciousMinds", "Ministry", "Worship"],
  authors: [{ name: "Precious Alakpa" }],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <DataProvider>
          {children}
          <Toaster />
        </DataProvider>
        {/* Designed by credit */}
        <footer className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
          <div className="text-center py-2">
            <span className="text-[10px] text-gray-400/60 font-light">
              Designed by Precious Alakpa
            </span>
          </div>
        </footer>
      </body>
    </html>
  );
}
