'use client'

import { useState, useEffect } from 'react'
import { useData } from '@/contexts/DataContext'
import { Course, Lesson, LessonStep } from '@/lib/data'
import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  ArrowLeft, BookOpen, Trophy, Flame, Star, Clock, CheckCircle, 
  Play, ChevronRight, Zap, Target, Award, TrendingUp, Users,
  BarChart3, Home, X, RotateCcw, Lightbulb, Heart, MessageCircle
} from 'lucide-react'
import dynamic from 'next/dynamic'

// Dynamic import for MathJax
const MathJax = dynamic(() => import('better-react-mathjax'), { ssr: false })

export default function LearnPage() {
  const { 
    currentUser, courses, lessons, getCourseProgress, getLessonProgress,
    startLesson, completeStep, completeLesson, getUserXP, getUserLevel, getStreak
  } = useData()
  
  const [view, setView] = useState<'catalog' | 'course' | 'lesson'>('catalog')
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null)
  const [currentStepIndex, setCurrentStepIndex] = useState(0)
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({})
  const [showHint, setShowHint] = useState(false)
  const [stepComplete, setStepComplete] = useState(false)
  const [dragItems, setDragItems] = useState<{id: string; content: string; zone?: string}[]>([])
  const [sortItems, setSortItems] = useState<{id: string; content: string}[]>([])
  const [sliderValue, setSliderValue] = useState(50)
  const [codeOutput, setCodeOutput] = useState('')
  const [showExplanation, setShowExplanation] = useState(false)
  
  // Get current step
  const currentStep = selectedLesson?.steps[currentStepIndex]
  const totalSteps = selectedLesson?.steps.length || 0
  const progressPercent = totalSteps > 0 ? ((currentStepIndex + 1) / totalSteps) * 100 : 0
  
  // Categories with icons
  const categories = [
    { id: 'math-foundations', name: 'Math Foundations', icon: '📐', color: 'bg-blue-500' },
    { id: 'algebra', name: 'Algebra', icon: '🔢', color: 'bg-purple-500' },
    { id: 'programming', name: 'Programming', icon: '💻', color: 'bg-green-500' },
    { id: 'data-science', name: 'Data Science', icon: '📊', color: 'bg-orange-500' },
    { id: 'science', name: 'Science', icon: '🔬', color: 'bg-cyan-500' },
    { id: 'logic', name: 'Logic', icon: '🧩', color: 'bg-pink-500' },
    { id: 'technology', name: 'Technology', icon: '⚡', color: 'bg-yellow-500' },
    { id: 'puzzles', name: 'Puzzles', icon: '🎮', color: 'bg-red-500' },
  ]
  
  // Initialize drag items when step changes
  useEffect(() => {
    if (currentStep?.type === 'drag-drop' && currentStep.content.dragItems) {
      setDragItems(currentStep.content.dragItems.map(item => ({ ...item, zone: undefined })))
    }
    if (currentStep?.type === 'drag-order' && currentStep.content.sortItems) {
      setSortItems([...currentStep.content.sortItems].sort(() => Math.random() - 0.5))
    }
    if (currentStep?.type === 'slider' && currentStep.content.sliderConfig) {
      setSliderValue(currentStep.content.sliderConfig.defaultValue)
    }
    setStepComplete(false)
    setShowExplanation(false)
    setShowHint(false)
    setUserAnswers({})
  }, [currentStepIndex, currentStep])
  
  // Handle selecting a course
  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course)
    setView('course')
  }
  
  // Handle selecting a lesson
  const handleSelectLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson)
    startLesson(lesson.id)
    setCurrentStepIndex(0)
    setView('lesson')
  }
  
  // Handle going back
  const handleBack = () => {
    if (view === 'lesson') {
      setView('course')
      setSelectedLesson(null)
    } else if (view === 'course') {
      setView('catalog')
      setSelectedCourse(null)
    }
  }
  
  // Check answer for different question types
  const checkAnswer = () => {
    if (!currentStep) return
    
    let isCorrect = false
    
    switch (currentStep.type) {
      case 'multiple-choice':
      case 'multiple-select':
        const selected = userAnswers[currentStep.id]
        const correct = currentStep.content.correctAnswer
        if (Array.isArray(correct)) {
          isCorrect = Array.isArray(selected) && 
            selected.length === correct.length && 
            selected.every(s => correct.includes(s))
        } else {
          isCorrect = selected === correct
        }
        break
        
      case 'fill-blank':
        const blanks = currentStep.content.blanks || []
        isCorrect = blanks.every(blank => {
          const userAnswer = userAnswers[blank.id]?.toLowerCase().trim()
          const correctAnswers = [blank.correctAnswer, ...(blank.acceptableAnswers || [])].map(a => a.toLowerCase())
          return correctAnswers.includes(userAnswer)
        })
        break
        
      case 'sorting':
        const correctOrder = currentStep.content.correctOrder || []
        isCorrect = sortItems.every((item, index) => item.id === correctOrder[index])
        break
        
      case 'matching':
        const pairs = currentStep.content.matchingPairs || []
        isCorrect = pairs.every(pair => userAnswers[pair.left.id] === pair.right.id)
        break
        
      case 'slider':
        const config = currentStep.content.sliderConfig
        if (config?.correctValue !== undefined) {
          isCorrect = sliderValue === config.correctValue
        } else if (config?.correctRange) {
          isCorrect = sliderValue >= config.correctRange.min && sliderValue <= config.correctRange.max
        } else {
          isCorrect = true // No correct answer, just exploration
        }
        break
        
      default:
        isCorrect = true
    }
    
    if (isCorrect) {
      completeStep(selectedLesson?.id || '', currentStep.id, true)
      setStepComplete(true)
    }
    
    setShowExplanation(true)
  }
  
  // Move to next step
  const nextStep = () => {
    if (!selectedLesson) return
    
    if (currentStepIndex < selectedLesson.steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1)
    } else {
      // Complete lesson
      completeLesson(selectedLesson.id)
      setView('course')
      setSelectedLesson(null)
    }
  }
  
  // Render step content based on type
  const renderStepContent = () => {
    if (!currentStep) return null
    
    const content = currentStep.content
    
    switch (currentStep.type) {
      case 'text':
        return (
          <div className="space-y-4">
            {content.title && <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>}
            <p className="text-gray-700 leading-relaxed whitespace-pre-line">{content.text}</p>
          </div>
        )
        
      case 'image':
        return (
          <div className="space-y-4">
            {content.title && <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>}
            {content.text && <p className="text-gray-700">{content.text}</p>}
            {content.imageUrl && (
              <img src={content.imageUrl} alt={content.title} className="rounded-lg shadow-lg max-w-full" />
            )}
          </div>
        )
        
      case 'math':
        return (
          <div className="space-y-4">
            {content.title && <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>}
            {content.text && <p className="text-gray-700">{content.text}</p>}
            <div className="bg-gray-100 p-6 rounded-lg">
              <MathJax dynamic>
                {content.mathDisplay === 'block' ? (
                  <div className="text-2xl text-center">{`$$${content.latex}$$`}</div>
                ) : (
                  <span>{`$${content.latex}$`}</span>
                )}
              </MathJax>
            </div>
          </div>
        )
        
      case 'multiple-choice':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.question}</h2>
            <div className="space-y-3">
              {content.options?.map((option) => {
                const isSelected = userAnswers[currentStep.id] === option.id
                let buttonClass = "w-full p-4 text-left rounded-xl border-2 transition-all "
                
                if (showExplanation) {
                  if (option.isCorrect) {
                    buttonClass += "border-green-500 bg-green-50 text-green-800"
                  } else if (isSelected && !option.isCorrect) {
                    buttonClass += "border-red-500 bg-red-50 text-red-800"
                  } else {
                    buttonClass += "border-gray-200 bg-gray-50 text-gray-500"
                  }
                } else if (isSelected) {
                  buttonClass += "border-blue-500 bg-blue-50"
                } else {
                  buttonClass += "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                }
                
                return (
                  <button
                    key={option.id}
                    onClick={() => !showExplanation && setUserAnswers({ ...userAnswers, [currentStep.id]: option.id })}
                    className={buttonClass}
                    disabled={showExplanation}
                  >
                    <span className="font-medium">{option.text}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
        
      case 'multiple-select':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.question}</h2>
            <p className="text-sm text-gray-500">Select all that apply</p>
            <div className="space-y-3">
              {content.options?.map((option) => {
                const selected = userAnswers[currentStep.id] || []
                const isSelected = selected.includes(option.id)
                let buttonClass = "w-full p-4 text-left rounded-xl border-2 transition-all "
                
                if (showExplanation) {
                  if (option.isCorrect) {
                    buttonClass += "border-green-500 bg-green-50 text-green-800"
                  } else if (isSelected && !option.isCorrect) {
                    buttonClass += "border-red-500 bg-red-50 text-red-800"
                  } else {
                    buttonClass += "border-gray-200 bg-gray-50"
                  }
                } else if (isSelected) {
                  buttonClass += "border-blue-500 bg-blue-50"
                } else {
                  buttonClass += "border-gray-200 hover:border-blue-300"
                }
                
                return (
                  <button
                    key={option.id}
                    onClick={() => {
                      if (showExplanation) return
                      const current = userAnswers[currentStep.id] || []
                      const updated = isSelected
                        ? current.filter((id: string) => id !== option.id)
                        : [...current, option.id]
                      setUserAnswers({ ...userAnswers, [currentStep.id]: updated })
                    }}
                    className={buttonClass}
                    disabled={showExplanation}
                  >
                    <span className="font-medium">{option.text}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
        
      case 'fill-blank':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Fill in the Blank'}</h2>
            <div className="space-y-4">
              {content.blanks?.map((blank, index) => (
                <div key={blank.id} className="flex flex-col gap-2">
                  <label className="text-sm font-medium text-gray-600">Blank {index + 1}</label>
                  <Input
                    value={userAnswers[blank.id] || ''}
                    onChange={(e) => setUserAnswers({ ...userAnswers, [blank.id]: e.target.value })}
                    placeholder={blank.placeholder || 'Type your answer...'}
                    className={`text-lg p-4 ${
                      showExplanation
                        ? userAnswers[blank.id]?.toLowerCase().trim() === blank.correctAnswer.toLowerCase()
                          ? 'border-green-500 bg-green-50'
                          : 'border-red-500 bg-red-50'
                        : ''
                    }`}
                    disabled={showExplanation}
                  />
                  {showExplanation && (
                    <p className="text-sm text-green-600">Correct answer: {blank.correctAnswer}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )
        
      case 'sorting':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Arrange in Order'}</h2>
            <p className="text-gray-600">{content.text}</p>
            <div className="space-y-2">
              {sortItems.map((item, index) => (
                <div
                  key={item.id}
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData('text/plain', item.id)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault()
                    const draggedId = e.dataTransfer.getData('text/plain')
                    const draggedIndex = sortItems.findIndex(i => i.id === draggedId)
                    const newItems = [...sortItems]
                    newItems.splice(draggedIndex, 1)
                    newItems.splice(index, 0, sortItems[draggedIndex])
                    setSortItems(newItems)
                  }}
                  className="p-4 bg-white border-2 rounded-lg cursor-move hover:border-blue-400 flex items-center gap-3"
                >
                  <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
                    {index + 1}
                  </span>
                  <span>{item.content}</span>
                </div>
              ))}
            </div>
          </div>
        )
        
      case 'slider':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Adjust the Value'}</h2>
            <p className="text-gray-600">{content.text}</p>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min={content.sliderConfig?.min || 0}
                  max={content.sliderConfig?.max || 100}
                  step={content.sliderConfig?.step || 1}
                  value={sliderValue}
                  onChange={(e) => setSliderValue(Number(e.target.value))}
                  className="flex-1 h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-2xl font-bold text-blue-600 w-20 text-right">
                  {sliderValue}{content.sliderConfig?.unit || ''}
                </span>
              </div>
              <p className="text-center text-gray-500">{content.sliderConfig?.label}</p>
            </div>
          </div>
        )
        
      case 'code':
        return (
          <div className="space-y-4">
            {content.title && <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>}
            {content.text && <p className="text-gray-700">{content.text}</p>}
            <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-gray-100">
                <code>{content.code}</code>
              </pre>
            </div>
          </div>
        )
        
      case 'interactive':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Interactive'}</h2>
            <p className="text-gray-600">{content.text}</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {content.interactiveConfig?.elements.map((element) => (
                <div
                  key={element.id}
                  onClick={() => setUserAnswers({ ...userAnswers, [currentStep.id]: element.id })}
                  className={`p-6 rounded-xl cursor-pointer transition-all text-center ${
                    userAnswers[currentStep.id] === element.id
                      ? 'ring-4 ring-blue-500 scale-105'
                      : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: element.color || '#4A90E2' }}
                >
                  <span className="text-white font-medium">{element.content}</span>
                </div>
              ))}
            </div>
          </div>
        )
        
      case 'graph':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Graph'}</h2>
            <p className="text-gray-600">{content.text}</p>
            <div className="bg-white border-2 rounded-xl p-4 h-64 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <BarChart3 className="w-16 h-16 mx-auto mb-2" />
                <p>Interactive Graph</p>
                <p className="text-sm">Click to plot points</p>
              </div>
            </div>
          </div>
        )
        
      case 'simulation':
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">{content.title || 'Simulation'}</h2>
            <p className="text-gray-600">{content.text}</p>
            <div className="bg-gradient-to-b from-gray-100 to-white border-2 rounded-xl p-4 h-64 relative overflow-hidden">
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-20 h-20 bg-blue-500 rounded-full animate-bounce" />
              <div className="absolute bottom-0 left-0 right-0 h-4 bg-gray-300" />
            </div>
            <Button onClick={() => {}} variant="outline">
              <RotateCcw className="w-4 h-4 mr-2" /> Reset Simulation
            </Button>
          </div>
        )
        
      default:
        return (
          <div className="space-y-4">
            {content.title && <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>}
            {content.text && <p className="text-gray-700">{content.text}</p>}
          </div>
        )
    }
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="hover:bg-gray-100"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="dark" />
          </div>
          
          {view === 'lesson' && selectedLesson && (
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-600">
                Step {currentStepIndex + 1} of {totalSteps}
              </div>
              <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
          
          {currentUser && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1 text-orange-500">
                <Flame className="w-5 h-5" />
                <span className="font-bold">{getStreak()}</span>
              </div>
              <div className="flex items-center gap-1 text-blue-600">
                <Star className="w-5 h-5" />
                <span className="font-bold">{getUserXP()} XP</span>
              </div>
            </div>
          )}
        </div>
      </header>
      
      <main className="pt-16 pb-8">
        {/* Catalog View */}
        {view === 'catalog' && (
          <div className="max-w-7xl mx-auto px-4 py-8">
            {/* Hero */}
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                💎 PreciousMinds
              </h1>
              <p className="text-xl text-gray-600">
                Interactive learning that makes you smarter every day
              </p>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <Card>
                <CardContent className="p-4 text-center">
                  <Star className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                  <p className="text-2xl font-bold">{getUserXP()}</p>
                  <p className="text-gray-500 text-sm">XP Earned</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Flame className="w-8 h-8 mx-auto mb-2 text-orange-500" />
                  <p className="text-2xl font-bold">{getStreak()}</p>
                  <p className="text-gray-500 text-sm">Day Streak</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Trophy className="w-8 h-8 mx-auto mb-2 text-purple-500" />
                  <p className="text-2xl font-bold">Level {getUserLevel()}</p>
                  <p className="text-gray-500 text-sm">Your Level</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <BookOpen className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                  <p className="text-2xl font-bold">{courses.length}</p>
                  <p className="text-gray-500 text-sm">Courses</p>
                </CardContent>
              </Card>
            </div>
            
            {/* Categories */}
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Learning Paths</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              {categories.map((cat) => {
                const catCourses = courses.filter(c => c.category === cat.id)
                if (catCourses.length === 0) return null
                return (
                  <Card key={cat.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                    <CardContent className="p-4">
                      <div className={`w-12 h-12 ${cat.color} rounded-xl flex items-center justify-center text-2xl mb-3`}>
                        {cat.icon}
                      </div>
                      <h3 className="font-semibold text-gray-900">{cat.name}</h3>
                      <p className="text-sm text-gray-500">{catCourses.length} courses</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
            
            {/* All Courses */}
            <h2 className="text-2xl font-bold text-gray-900 mb-6">All Courses</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => {
                const progress = getCourseProgress(course.id)
                const courseLessons = lessons.filter(l => l.courseId === course.id)
                const cat = categories.find(c => c.id === course.category)
                
                return (
                  <Card 
                    key={course.id} 
                    className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1"
                    onClick={() => handleSelectCourse(course)}
                  >
                    <CardContent className="p-0">
                      <div className={`${cat?.color || 'bg-gray-500'} h-2 rounded-t-lg`} />
                      <div className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <span className="text-2xl">{cat?.icon || '📚'}</span>
                          <span className="text-xs bg-gray-100 px-2 py-1 rounded-full capitalize">
                            {course.difficulty}
                          </span>
                        </div>
                        <h3 className="font-bold text-lg text-gray-900 mb-2">{course.title}</h3>
                        <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">
                            {courseLessons.length} lessons
                          </span>
                          <span className="text-blue-600 font-medium">
                            {course.totalXP} XP
                          </span>
                        </div>
                        {progress > 0 && (
                          <div className="mt-4">
                            <div className="flex justify-between text-xs text-gray-500 mb-1">
                              <span>Progress</span>
                              <span>{progress}%</span>
                            </div>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-green-500"
                                style={{ width: `${progress}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        )}
        
        {/* Course View */}
        {view === 'course' && selectedCourse && (
          <div className="max-w-4xl mx-auto px-4 py-8">
            <Button variant="ghost" onClick={handleBack} className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Courses
            </Button>
            
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{selectedCourse.title}</h1>
              <p className="text-gray-600">{selectedCourse.description}</p>
              <div className="flex items-center gap-6 mt-4">
                <span className="flex items-center gap-2 text-sm text-gray-500">
                  <BookOpen className="w-4 h-4" />
                  {lessons.filter(l => l.courseId === selectedCourse.id).length} lessons
                </span>
                <span className="flex items-center gap-2 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  ~{lessons.filter(l => l.courseId === selectedCourse.id).reduce((sum, l) => sum + l.estimatedMinutes, 0)} min
                </span>
                <span className="flex items-center gap-2 text-sm text-blue-600">
                  <Star className="w-4 h-4" />
                  {selectedCourse.totalXP} XP
                </span>
              </div>
            </div>
            
            <div className="space-y-4">
              {lessons
                .filter(l => l.courseId === selectedCourse.id)
                .sort((a, b) => a.order - b.order)
                .map((lesson, index) => {
                  const progress = getLessonProgress(lesson.id)
                  const isCompleted = progress?.status === 'completed'
                  const isInProgress = progress?.status === 'in-progress'
                  
                  return (
                    <Card 
                      key={lesson.id}
                      className={`cursor-pointer transition-all hover:shadow-lg ${
                        isCompleted ? 'border-green-300 bg-green-50' : ''
                      }`}
                      onClick={() => handleSelectLesson(lesson)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            isCompleted 
                              ? 'bg-green-500 text-white' 
                              : isInProgress
                                ? 'bg-blue-500 text-white'
                                : 'bg-gray-200 text-gray-600'
                          }`}>
                            {isCompleted ? (
                              <CheckCircle className="w-5 h-5" />
                            ) : (
                              <span className="font-bold">{index + 1}</span>
                            )}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{lesson.title}</h3>
                            <p className="text-sm text-gray-500">{lesson.description}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-sm text-gray-400">{lesson.estimatedMinutes} min</span>
                            <span className="text-sm font-medium text-blue-600">+{lesson.xpReward} XP</span>
                            <ChevronRight className="w-5 h-5 text-gray-400" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
            </div>
          </div>
        )}
        
        {/* Lesson View */}
        {view === 'lesson' && selectedLesson && currentStep && (
          <div className="max-w-3xl mx-auto px-4 py-8">
            <Button variant="ghost" onClick={handleBack} className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Course
            </Button>
            
            <Card className="mb-6">
              <CardContent className="p-8">
                {/* Step Content */}
                {renderStepContent()}
                
                {/* Hint */}
                {currentStep.content.hint && showHint && !showExplanation && (
                  <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center gap-2 text-yellow-700">
                      <Lightbulb className="w-5 h-5" />
                      <span className="font-medium">Hint</span>
                    </div>
                    <p className="mt-2 text-yellow-800">{currentStep.content.hint}</p>
                  </div>
                )}
                
                {/* Explanation */}
                {showExplanation && currentStep.content.explanation && (
                  <div className={`mt-6 p-4 rounded-lg ${
                    stepComplete ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                  }`}>
                    <div className={`flex items-center gap-2 ${
                      stepComplete ? 'text-green-700' : 'text-red-700'
                    }`}>
                      {stepComplete ? (
                        <>
                          <CheckCircle className="w-5 h-5" />
                          <span className="font-medium">Correct!</span>
                        </>
                      ) : (
                        <>
                          <X className="w-5 h-5" />
                          <span className="font-medium">Not quite</span>
                        </>
                      )}
                    </div>
                    <p className={`mt-2 ${stepComplete ? 'text-green-800' : 'text-red-800'}`}>
                      {currentStep.content.explanation}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Action Buttons */}
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                {currentStep.content.hint && !showExplanation && (
                  <Button 
                    variant="outline" 
                    onClick={() => setShowHint(true)}
                  >
                    <Lightbulb className="w-4 h-4 mr-2" /> Show Hint
                  </Button>
                )}
              </div>
              
              <div className="flex gap-2">
                {!showExplanation && ['multiple-choice', 'multiple-select', 'fill-blank', 'sorting', 'matching', 'slider'].includes(currentStep.type) && (
                  <Button 
                    onClick={checkAnswer}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" /> Check Answer
                  </Button>
                )}
                
                {(showExplanation || !['multiple-choice', 'multiple-select', 'fill-blank', 'sorting', 'matching', 'slider'].includes(currentStep.type)) && (
                  <Button 
                    onClick={nextStep}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {currentStepIndex < selectedLesson.steps.length - 1 ? (
                      <>Next Step <ChevronRight className="w-4 h-4 ml-2" /></>
                    ) : (
                      <>Complete Lesson <Trophy className="w-4 h-4 ml-2" /></>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
