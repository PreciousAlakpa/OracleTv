'use client'

import { useData } from '@/contexts/DataContext'
import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ArrowLeft, Play, Youtube, Facebook } from 'lucide-react'

export default function WatchPage() {
  const { videos } = useData()

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30 bg-gray-900/95 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="light" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white mb-6">All Videos</h1>
          
          {videos.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Play className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>No videos available yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {videos.map((video) => (
                <Card key={video.id} className="bg-gray-800 border-gray-700 overflow-hidden hover:border-gray-600 transition-colors">
                  <CardContent className="p-0">
                    <div className="aspect-video bg-gray-900 relative">
                      <iframe
                        src={video.videoUrl}
                        className="w-full h-full"
                        allowFullScreen
                      />
                      <div className="absolute top-2 right-2">
                        {video.type === 'youtube' ? (
                          <div className="bg-red-600 p-1.5 rounded-full">
                            <Youtube className="w-4 h-4 text-white" />
                          </div>
                        ) : (
                          <div className="bg-blue-600 p-1.5 rounded-full">
                            <Facebook className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-semibold text-lg mb-1">{video.title}</h3>
                      <p className="text-gray-400 text-sm">{video.description}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
