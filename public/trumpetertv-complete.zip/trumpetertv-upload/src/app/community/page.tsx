'use client'

import { useState } from 'react'
import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useData } from '@/contexts/DataContext'
import { ArrowLeft, Users, Calendar, MessageCircle, Heart, Clock, Send, BookOpen } from 'lucide-react'

const communityEvents = [
  { id: '1', title: 'Sunday Service', date: 'Every Sunday', time: '10:00 AM', description: 'Join us for our weekly worship service' },
  { id: '2', title: 'Bible Study', date: 'Every Wednesday', time: '7:00 PM', description: 'Deep dive into the Scriptures' },
  { id: '3', title: 'Youth Fellowship', date: 'Every Friday', time: '6:00 PM', description: 'For young adults and teens' },
  { id: '4', title: 'Prayer Meeting', date: 'Every Saturday', time: '5:00 AM', description: 'Early morning prayer gathering' },
]

export default function CommunityPage() {
  const { prayerRequests, testimonies, isLoggedIn, login, logout, addPrayerRequest, addTestimony } = useData()
  
  // Login form state
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  
  // Prayer request form
  const [prayerName, setPrayerName] = useState('')
  const [prayerText, setPrayerText] = useState('')
  
  // Testimony form
  const [testimonyName, setTestimonyName] = useState('')
  const [testimonyText, setTestimonyText] = useState('')
  
  // Active tab for dashboard
  const [activeTab, setActiveTab] = useState('overview')

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setLoginError('')
    
    if (login(email, password)) {
      setEmail('')
      setPassword('')
    } else {
      setLoginError('Invalid email or password')
    }
  }

  const handlePrayerRequest = (e: React.FormEvent) => {
    e.preventDefault()
    if (!prayerText.trim()) return
    
    addPrayerRequest({
      name: prayerName || 'Anonymous',
      request: prayerText,
      isPublic: true
    })
    
    setPrayerText('')
    alert('Prayer request submitted! Our community will be praying for you.')
  }

  const handleTestimony = (e: React.FormEvent) => {
    e.preventDefault()
    if (!testimonyText.trim()) return
    
    addTestimony({
      name: testimonyName || 'Anonymous',
      testimony: testimonyText,
      isPublic: true
    })
    
    setTestimonyText('')
    alert('Testimony shared! Thank you for sharing what God has done.')
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30 bg-gray-900/95 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="light" />
          </div>
          {isLoggedIn && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={logout}
              className="border-white/20 text-white hover:bg-white/10"
            >
              Logout
            </Button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-8 px-4">
        <div className="container mx-auto max-w-4xl">
          {!isLoggedIn ? (
            /* Login Section */
            <div className="space-y-6">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-white mb-2">Community Access</h1>
                <p className="text-gray-400">Enter your credentials to join the community</p>
              </div>
              
              {/* Stats - Visible to all */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4 text-center">
                    <Users className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                    <p className="text-2xl font-bold text-white">500+</p>
                    <p className="text-gray-400 text-sm">Members</p>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4 text-center">
                    <Calendar className="w-8 h-8 mx-auto mb-2 text-green-400" />
                    <p className="text-2xl font-bold text-white">12</p>
                    <p className="text-gray-400 text-sm">Events Monthly</p>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4 text-center">
                    <MessageCircle className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                    <p className="text-2xl font-bold text-white">{prayerRequests.length}+</p>
                    <p className="text-gray-400 text-sm">Prayer Requests</p>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4 text-center">
                    <Heart className="w-8 h-8 mx-auto mb-2 text-red-400" />
                    <p className="text-2xl font-bold text-white">{testimonies.length}+</p>
                    <p className="text-gray-400 text-sm">Testimonies</p>
                  </CardContent>
                </Card>
              </div>

              {/* Login Card */}
              <Card className="bg-gray-800 border-gray-700 max-w-md mx-auto">
                <CardHeader>
                  <CardTitle className="text-white text-center">Login to Community</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleLogin} className="space-y-4">
                    {loginError && (
                      <div className="bg-red-500/20 border border-red-500/50 text-red-200 p-3 rounded-lg text-sm text-center">
                        {loginError}
                      </div>
                    )}
                    <div>
                      <Label className="text-gray-300">Email</Label>
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter email"
                        className="mt-2 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Password</Label>
                      <Input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password"
                        className="mt-2 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Login
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Dashboard Section */
            <div className="space-y-6">
              <div className="text-center mb-6">
                <h1 className="text-3xl font-bold text-white mb-2">
                  Welcome to TRUMPETER TV Community! 👋
                </h1>
                <p className="text-gray-400">Connect, grow, and share with fellow believers</p>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
                  <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                    Overview
                  </TabsTrigger>
                  <TabsTrigger value="prayers" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                    Prayers
                  </TabsTrigger>
                  <TabsTrigger value="testimonies" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                    Testimonies
                  </TabsTrigger>
                  <TabsTrigger value="events" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                    Events
                  </TabsTrigger>
                </TabsList>

                {/* Overview Tab */}
                <TabsContent value="overview" className="space-y-6">
                  {/* Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4 text-center">
                        <Users className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                        <p className="text-2xl font-bold text-white">500+</p>
                        <p className="text-gray-400 text-sm">Members</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4 text-center">
                        <Calendar className="w-8 h-8 mx-auto mb-2 text-green-400" />
                        <p className="text-2xl font-bold text-white">{communityEvents.length}</p>
                        <p className="text-gray-400 text-sm">Weekly Events</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4 text-center">
                        <MessageCircle className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                        <p className="text-2xl font-bold text-white">{prayerRequests.length}</p>
                        <p className="text-gray-400 text-sm">Prayer Requests</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4 text-center">
                        <Heart className="w-8 h-8 mx-auto mb-2 text-red-400" />
                        <p className="text-2xl font-bold text-white">{testimonies.length}</p>
                        <p className="text-gray-400 text-sm">Testimonies</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Upcoming Events */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Calendar className="w-5 h-5" />
                        Upcoming Events
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {communityEvents.map((event) => (
                          <div 
                            key={event.id}
                            className="p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors"
                          >
                            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                              <div>
                                <h3 className="text-white font-semibold">{event.title}</h3>
                                <p className="text-gray-400 text-sm">{event.description}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-blue-400 text-sm">{event.date}</p>
                                <p className="text-gray-400 text-sm">{event.time}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Prayers Tab */}
                <TabsContent value="prayers" className="space-y-6">
                  {/* Submit Prayer Request */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <MessageCircle className="w-5 h-5" />
                        Submit Prayer Request
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        Share your prayer needs with our community
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handlePrayerRequest} className="space-y-4">
                        <Input
                          value={prayerName}
                          onChange={(e) => setPrayerName(e.target.value)}
                          placeholder="Your name (or leave blank for Anonymous)"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                        <Textarea
                          value={prayerText}
                          onChange={(e) => setPrayerText(e.target.value)}
                          placeholder="Share your prayer request..."
                          className="bg-gray-700 border-gray-600 text-white min-h-[100px]"
                        />
                        <Button type="submit" className="w-full bg-yellow-600 hover:bg-yellow-700">
                          <Send className="w-4 h-4 mr-2" />
                          Submit Prayer Request
                        </Button>
                      </form>
                    </CardContent>
                  </Card>

                  {/* Recent Prayer Requests */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Recent Prayer Requests</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {prayerRequests.length > 0 ? (
                          prayerRequests.map((prayer) => (
                            <div key={prayer.id} className="p-4 bg-gray-700/50 rounded-lg">
                              <p className="text-white">{prayer.request}</p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-gray-400 text-sm">- {prayer.name}</span>
                                <span className="text-gray-500 text-xs">{formatDate(prayer.createdAt)}</span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-400 text-center py-8">No prayer requests yet. Be the first!</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Testimonies Tab */}
                <TabsContent value="testimonies" className="space-y-6">
                  {/* Share Testimony */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Heart className="w-5 h-5" />
                        Share Your Testimony
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        Share what God has done in your life
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleTestimony} className="space-y-4">
                        <Input
                          value={testimonyName}
                          onChange={(e) => setTestimonyName(e.target.value)}
                          placeholder="Your name (or leave blank for Anonymous)"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                        <Textarea
                          value={testimonyText}
                          onChange={(e) => setTestimonyText(e.target.value)}
                          placeholder="Share your testimony..."
                          className="bg-gray-700 border-gray-600 text-white min-h-[100px]"
                        />
                        <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                          <Heart className="w-4 h-4 mr-2" />
                          Share Testimony
                        </Button>
                      </form>
                    </CardContent>
                  </Card>

                  {/* Recent Testimonies */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Recent Testimonies</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {testimonies.length > 0 ? (
                          testimonies.map((testimony) => (
                            <div key={testimony.id} className="p-4 bg-gray-700/50 rounded-lg">
                              <p className="text-white">{testimony.testimony}</p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-gray-400 text-sm">- {testimony.name}</span>
                                <span className="text-gray-500 text-xs">{formatDate(testimony.createdAt)}</span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-400 text-center py-8">No testimonies yet. Be the first to share!</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Events Tab */}
                <TabsContent value="events" className="space-y-4">
                  {communityEvents.map((event) => (
                    <Card key={event.id} className="bg-gray-800 border-gray-700">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="bg-blue-600 p-3 rounded-lg">
                            <Calendar className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-white text-lg font-semibold">{event.title}</h3>
                            <p className="text-gray-400 mt-1">{event.description}</p>
                            <div className="flex items-center gap-4 mt-3">
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4 text-blue-400" />
                                <span className="text-blue-400 text-sm">{event.time}</span>
                              </div>
                              <span className="text-gray-500 text-sm">{event.date}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {/* Bible Reading Plan */}
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="bg-purple-600 p-3 rounded-lg">
                          <BookOpen className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-white text-lg font-semibold">Daily Bible Reading</h3>
                          <p className="text-gray-400 mt-1">Join us as we read through the Bible together</p>
                          <Button 
                            onClick={() => window.open('https://www.bible.com', '_blank')}
                            className="mt-3 bg-purple-600 hover:bg-purple-700"
                          >
                            Open Bible App
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
