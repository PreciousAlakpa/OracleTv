'use client'

import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Music, Play } from 'lucide-react'

const musicList = [
  { id: '1', title: 'Amazing Grace', duration: '4:32' },
  { id: '2', title: 'How Great Is Our God', duration: '5:15' },
  { id: '3', title: '10,000 Reasons', duration: '4:58' },
  { id: '4', title: 'In Christ Alone', duration: '4:45' },
  { id: '5', title: 'Blessed Assurance', duration: '3:52' },
]

export default function MusicPage() {
  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30 bg-gray-900/95 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="light" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-8 px-4">
        <div className="container mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold text-white mb-6">Music</h1>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Music className="w-5 h-5" />
                Worship Songs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {musicList.map((song, index) => (
                  <div 
                    key={song.id}
                    className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors group"
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-gray-400 w-6">{index + 1}</span>
                      <span className="text-white">{song.title}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-gray-400 text-sm">{song.duration}</span>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-white hover:bg-white/10"
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
