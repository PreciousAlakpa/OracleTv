'use client'

import { useState } from 'react'
import { useData } from '@/contexts/DataContext'
import Logo from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { ArrowLeft, Settings, Youtube, Facebook, ImageIcon, Video, Plus, Trash2, Save } from 'lucide-react'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export default function AdminDashboard() {
  const { settings, updateSettings, slides, addSlide, removeSlide, videos, addVideo, removeVideo } = useData()
  
  const [youtubeUrl, setYoutubeUrl] = useState(settings?.youtube_live_url || '')
  const [facebookUrl, setFacebookUrl] = useState(settings?.facebook_live_url || '')
  const [siteName, setSiteName] = useState(settings?.site_name || '')
  const [slideUrl, setSlideUrl] = useState('')
  const [videoUrl, setVideoUrl] = useState('')
  const [videoTitle, setVideoTitle] = useState('')

  const saveLiveSettings = () => {
    updateSettings({
      site_name: siteName,
      youtube_live_url: youtubeUrl,
      facebook_live_url: facebookUrl
    })
    alert('Settings saved!')
  }

  const addNewSlide = () => {
    if (!slideUrl.trim()) return
    addSlide({
      id: Date.now().toString(),
      imageUrl: slideUrl,
      title: 'Custom Slide'
    })
    setSlideUrl('')
  }

  const addNewVideo = () => {
    if (!videoUrl.trim()) return
    
    let embedUrl = videoUrl
    let youtubeId = ''
    
    if (videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')) {
      const match = videoUrl.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/)
      if (match) {
        youtubeId = match[1]
        embedUrl = `https://www.youtube.com/embed/${match[1]}`
      }
    }
    
    addVideo({
      id: Date.now().toString(),
      title: videoTitle || 'New Video',
      description: 'Added from admin',
      video_url: embedUrl,
      youtube_id: youtubeId,
      is_live: false,
      duration: 300
    })
    setVideoUrl('')
    setVideoTitle('')
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.location.href = '/'}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Logo size="sm" variant="light" />
          </div>
          <h2 className="text-white font-semibold">Admin Dashboard</h2>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto p-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Admin Dashboard</h1>

        <Tabs defaultValue="live" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white border mb-6">
            <TabsTrigger value="live" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Settings className="w-4 h-4 mr-2" />
              Live Settings
            </TabsTrigger>
            <TabsTrigger value="slides" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <ImageIcon className="w-4 h-4 mr-2" />
              Slides
            </TabsTrigger>
            <TabsTrigger value="videos" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Video className="w-4 h-4 mr-2" />
              Videos
            </TabsTrigger>
          </TabsList>

          {/* Live Settings Tab */}
          <TabsContent value="live">
            <Card className="bg-white">
              <CardHeader>
                <CardTitle>Live Stream URLs</CardTitle>
                <CardDescription>
                  Configure your YouTube and Facebook live stream URLs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="flex items-center gap-2">
                    Site Name
                  </Label>
                  <Input
                    value={siteName}
                    onChange={(e) => setSiteName(e.target.value)}
                    placeholder="TRUMPETER TV"
                    className="mt-2"
                  />
                </div>
                
                <div>
                  <Label className="flex items-center gap-2">
                    <Youtube className="w-4 h-4 text-red-500" />
                    YouTube Live URL
                  </Label>
                  <Input
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    placeholder="https://www.youtube.com/embed/live_stream?channel=YOUR_CHANNEL_ID"
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Format: https://www.youtube.com/embed/live_stream?channel=CHANNEL_ID
                  </p>
                </div>
                
                <div>
                  <Label className="flex items-center gap-2">
                    <Facebook className="w-4 h-4 text-blue-500" />
                    Facebook Live URL
                  </Label>
                  <Input
                    value={facebookUrl}
                    onChange={(e) => setFacebookUrl(e.target.value)}
                    placeholder="https://www.facebook.com/yourpage/videos/123456789"
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Paste your Facebook video URL directly
                  </p>
                </div>
                
                <Button onClick={saveLiveSettings} className="w-full bg-blue-600 hover:bg-blue-700">
                  <Save className="w-4 h-4 mr-2" />
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Slides Tab */}
          <TabsContent value="slides">
            <Card className="bg-white mb-6">
              <CardHeader>
                <CardTitle>Add New Slide</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Input
                    value={slideUrl}
                    onChange={(e) => setSlideUrl(e.target.value)}
                    placeholder="Enter image URL..."
                    className="flex-1"
                  />
                  <Button onClick={addNewSlide} className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {slides.map((slide) => (
                <div key={slide.id} className="relative group">
                  <div 
                    className="aspect-video bg-cover bg-center rounded-lg bg-gray-200"
                    style={{ backgroundImage: `url(${slide.imageUrl})` }}
                  />
                  <button
                    onClick={() => removeSlide(slide.id)}
                    className="absolute top-2 right-2 p-2 bg-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4 text-white" />
                  </button>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Videos Tab */}
          <TabsContent value="videos">
            <Card className="bg-white mb-6">
              <CardHeader>
                <CardTitle>Add New Video</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-4">
                  <Input
                    value={videoTitle}
                    onChange={(e) => setVideoTitle(e.target.value)}
                    placeholder="Video title..."
                  />
                  <div className="flex gap-4">
                    <Input
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      placeholder="YouTube video URL..."
                      className="flex-1"
                    />
                    <Button onClick={addNewVideo} className="bg-green-600 hover:bg-green-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {videos.map((video) => (
                <div key={video.id} className="flex items-center gap-4 p-4 bg-white rounded-lg border">
                  <div className="flex-1">
                    <h3 className="font-medium">{video.title}</h3>
                    <p className="text-gray-500 text-sm flex items-center gap-2">
                      {video.youtube_id ? (
                        <>
                          <Youtube className="w-3 h-3 text-red-500" />
                          YouTube
                        </>
                      ) : video.video_url?.includes('facebook') ? (
                        <>
                          <Facebook className="w-3 h-3 text-blue-500" />
                          Facebook
                        </>
                      ) : null}
                    </p>
                  </div>
                  <Button
                    onClick={() => removeVideo(video.id)}
                    variant="ghost"
                    className="text-red-500 hover:text-red-300 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
