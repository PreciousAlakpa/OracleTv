'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import Logo from '@/components/Logo'
import { useData } from '@/contexts/DataContext'
import { Video } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  MessageCircle, Heart, MapPin, Globe, Mic, Languages, BookOpen, 
  Download, Phone, Share2, Bell, Users, Clock, Send, X, Check
} from 'lucide-react'

export default function LivePage() {
  const { settings, videos, loading } = useData()
  const [sideMenuOpen, setSideMenuOpen] = useState(false)
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0)
  const [isMuted, setIsMuted] = useState(true)
  const [videoKey, setVideoKey] = useState(0)
  const [sourceTab, setSourceTab] = useState<'youtube' | 'facebook'>('youtube')
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // ========== FEATURE STATES ==========
  // Live Chat
  const [chatMessages, setChatMessages] = useState<{name: string; message: string; time: string}[]>([
    { name: 'John D.', message: 'Glory to God! 🙏', time: '10:30 AM' },
    { name: 'Mary K.', message: 'Blessed to be here', time: '10:31 AM' },
    { name: 'Pastor Tom', message: 'Welcome everyone!', time: '10:32 AM' },
  ])
  const [chatName, setChatName] = useState('')
  const [chatMessage, setChatMessage] = useState('')
  
  // Prayer Wall
  const [prayerRequests, setPrayerRequests] = useState<{name: string; request: string; location: string}[]>([
    { name: 'Anonymous', request: 'Pray for my family', location: 'Lagos, Nigeria' },
    { name: 'Grace M.', request: 'Healing for my mother', location: 'Accra, Ghana' },
  ])
  const [prayerName, setPrayerName] = useState('')
  const [prayerText, setPrayerText] = useState('')
  const [prayerLocation, setPrayerLocation] = useState('')
  
  // Sermon Notes
  const [sermonNotes, setSermonNotes] = useState('')
  
  // Altar Call
  const [altarCallOpen, setAltarCallOpen] = useState(false)
  const [altarCallName, setAltarCallName] = useState('')
  const [altarCallPhone, setAltarCallPhone] = useState('')
  const [altarCallSubmitted, setAltarCallSubmitted] = useState(false)
  
  // Global Viewers
  const [viewerLocations, setViewerLocations] = useState<{country: string; city: string; count: number}[]>([])
  const [totalViewers, setTotalViewers] = useState(0)
  
  // Voice Commands
  const [voiceSupported, setVoiceSupported] = useState(false)
  const [voiceListening, setVoiceListening] = useState(false)
  
  // Language Translation
  const [selectedLanguage, setSelectedLanguage] = useState('en')
  const [translationEnabled, setTranslationEnabled] = useState(false)
  
  // Notifications
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default')
  const [showNotification, setShowNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')

  // ========== VIDEO QUEUE LOGIC ==========
  const getQueueVideos = useCallback((): Video[] => {
    const queue = settings?.tv_program_queue || []
    if (queue.length > 0) {
      return queue
        .map(id => videos.find(v => v.id === id))
        .filter((v): v is Video => v !== undefined)
    }
    return videos.filter(v => !v.is_live)
  }, [settings, videos])

  const queueVideos = getQueueVideos()
  const currentVideo = queueVideos[currentVideoIndex] || null

  // Extract YouTube ID
  const cleanYouTubeId = (input: string) => {
    if (!input) return ''
    if (/^[A-Za-z0-9_-]{11}$/.test(input.trim())) return input.trim()
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtube\.com\/watch\?.+&v=)([A-Za-z0-9_-]{11})/,
      /youtu\.be\/([A-Za-z0-9_-]{11})/,
      /youtube\.com\/embed\/([A-Za-z0-9_-]{11})/,
      /youtube\.com\/live\/([A-Za-z0-9_-]{11})/,
    ]
    for (const p of patterns) {
      const m = input.match(p)
      if (m) return m[1]
    }
    return ''
  }

  const isFacebookUrl = (url: string) => {
    if (!url) return false
    return url.includes('facebook.com') || url.includes('fb.watch')
  }

  const getFacebookEmbedUrl = (url: string) => {
    if (!url) return ''
    if (url.includes('facebook.com/plugins/video.php')) return url
    return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}`
  }

  const isYouTubeVideo = currentVideo && !!(cleanYouTubeId(currentVideo.youtube_id || '') || cleanYouTubeId(currentVideo.video_url || ''))
  const isFacebookVideo = currentVideo && isFacebookUrl(currentVideo.video_url || currentVideo.facebook_url || '')

  const getYouTubeEmbedUrl = (video: Video) => {
    const id = cleanYouTubeId(video.youtube_id || '') || cleanYouTubeId(video.video_url || '')
    if (!id) return ''
    return `https://www.youtube.com/embed/${id}?autoplay=1&mute=1&rel=0&modestbranding=1&playsinline=1&enablejsapi=1&origin=${typeof window !== 'undefined' ? window.location.origin : ''}`
  }

  const goNext = useCallback(() => {
    if (queueVideos.length === 0) return
    setCurrentVideoIndex(prev => (prev + 1) % queueVideos.length)
    setVideoKey(prev => prev + 1)
    setIsMuted(true)
  }, [queueVideos.length])

  // Auto-advance timer
  useEffect(() => {
    if (!currentVideo || queueVideos.length <= 1) return
    if (timerRef.current) clearTimeout(timerRef.current)
    
    const durationSeconds = currentVideo.duration > 0 ? currentVideo.duration : 300
    timerRef.current = setTimeout(() => goNext(), durationSeconds * 1000)
    
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [currentVideo?.id, currentVideo?.duration, queueVideos.length, goNext])

  // YouTube end event listener
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        if (typeof event.data === 'string') {
          const data = JSON.parse(event.data)
          if (data.event === 'onStateChange' && data.info === 0) {
            if (timerRef.current) clearTimeout(timerRef.current)
            goNext()
          }
        }
      } catch {}
    }
    window.addEventListener('message', handleMessage)
    return () => window.removeEventListener('message', handleMessage)
  }, [goNext])

  // ========== FEATURE EFFECTS ==========
  // Load saved data
  useEffect(() => {
    const savedName = localStorage.getItem('trumpeter_chat_name')
    if (savedName) setChatName(savedName)
    const savedLocation = localStorage.getItem('trumpeter_location')
    if (savedLocation) setPrayerLocation(savedLocation)
    const savedNotes = localStorage.getItem('trumpeter_notes')
    if (savedNotes) setSermonNotes(savedNotes)
  }, [])

  // Mock viewer locations
  useEffect(() => {
    const locations = [
      { country: 'Nigeria', city: 'Lagos', count: Math.floor(Math.random() * 100) + 50 },
      { country: 'Ghana', city: 'Accra', count: Math.floor(Math.random() * 50) + 20 },
      { country: 'Kenya', city: 'Nairobi', count: Math.floor(Math.random() * 40) + 15 },
      { country: 'USA', city: 'New York', count: Math.floor(Math.random() * 30) + 10 },
      { country: 'UK', city: 'London', count: Math.floor(Math.random() * 25) + 10 },
      { country: 'South Africa', city: 'Johannesburg', count: Math.floor(Math.random() * 40) + 5 },
    ]
    setViewerLocations(locations)
    setTotalViewers(locations.reduce((sum, l) => sum + l.count, 0))
  }, [])

  // Voice support check
  useEffect(() => {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      setVoiceSupported(true)
    }
  }, [])

  // ========== FEATURE HANDLERS ==========
  // Chat
  const handleSendChat = () => {
    if (!chatMessage.trim()) return
    const newMessage = {
      name: chatName || 'Anonymous',
      message: chatMessage,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    }
    setChatMessages(prev => [...prev, newMessage])
    setChatMessage('')
    if (chatName) localStorage.setItem('trumpeter_chat_name', chatName)
  }

  // Prayer Request
  const handlePrayerSubmit = () => {
    if (!prayerText.trim()) return
    const newRequest = {
      name: prayerName || 'Anonymous',
      request: prayerText,
      location: prayerLocation || 'Unknown'
    }
    setPrayerRequests(prev => [newRequest, ...prev])
    setPrayerText('')
    if (prayerLocation) localStorage.setItem('trumpeter_location', prayerLocation)
    triggerNotification('Prayer request submitted! 🙏')
  }

  // Sermon Notes
  const handleSaveNotes = () => {
    localStorage.setItem('trumpeter_notes', sermonNotes)
    triggerNotification('Notes saved! 📝')
  }

  // Altar Call
  const handleAltarCall = () => {
    if (!altarCallName.trim()) return
    setAltarCallSubmitted(true)
    triggerNotification('Altar call submitted! Pastor will contact you. 🙏')
    setTimeout(() => {
      setAltarCallOpen(false)
      setAltarCallSubmitted(false)
      setAltarCallName('')
      setAltarCallPhone('')
    }, 3000)
  }

  // Voice Commands
  const startVoiceCommand = () => {
    if (!voiceSupported) return
    // @ts-ignore
    const recognition = new webkitSpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    
    recognition.onstart = () => setVoiceListening(true)
    recognition.onend = () => setVoiceListening(false)
    
    recognition.onresult = (event: any) => {
      const command = event.results[0][0].transcript.toLowerCase()
      handleVoiceCommand(command)
    }
    
    recognition.start()
  }

  const handleVoiceCommand = (command: string) => {
    if (command.includes('next')) {
      goNext()
      triggerNotification('Going to next video')
    } else if (command.includes('mute')) {
      setIsMuted(true)
      triggerNotification('Video muted')
    } else if (command.includes('unmute')) {
      setIsMuted(false)
      triggerNotification('Video unmuted')
    } else if (command.includes('facebook')) {
      setSourceTab('facebook')
      triggerNotification('Switched to Facebook Live')
    } else if (command.includes('youtube')) {
      setSourceTab('youtube')
      triggerNotification('Switched to YouTube')
    } else {
      triggerNotification(`Command: "${command}"`)
    }
  }

  // Share
  const handleShare = async () => {
    const shareData = {
      title: settings?.site_name || 'TRUMPETER TV',
      text: 'Watch our live service!',
      url: window.location.href
    }
    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch {}
    } else {
      navigator.clipboard.writeText(window.location.href)
      triggerNotification('Link copied to clipboard! 📋')
    }
  }

  // Notifications
  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) return
    const permission = await Notification.requestPermission()
    setNotificationPermission(permission)
    if (permission === 'granted') {
      triggerNotification('Notifications enabled! 🔔')
    }
  }

  const triggerNotification = (message: string) => {
    setNotificationMessage(message)
    setShowNotification(true)
    setTimeout(() => setShowNotification(false), 3000)
  }

  // Download Video Info
  const handleDownload = () => {
    if (!currentVideo) return
    const data = {
      title: currentVideo.title,
      description: currentVideo.description,
      notes: sermonNotes
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${currentVideo.title || 'sermon'}.json`
    a.click()
    triggerNotification('Download started! 📥')
  }

  // SMS Prayer Line
  const smsPrayerLine = () => {
    window.open('sms:+1234567890?body=I need prayer', '_blank')
  }

  // Bible App
  const openBibleApp = () => {
    window.open('https://www.bible.com', '_blank')
  }

  // Growth Tracker
  const [growthStats, setGrowthStats] = useState({ services: 0, notes: 0, prayers: 0 })
  useEffect(() => {
    const stats = localStorage.getItem('trumpeter_growth')
    if (stats) setGrowthStats(JSON.parse(stats))
  }, [])
  const updateGrowth = (type: 'services' | 'notes' | 'prayers') => {
    const updated = { ...growthStats, [type]: growthStats[type] + 1 }
    setGrowthStats(updated)
    localStorage.setItem('trumpeter_growth', JSON.stringify(updated))
  }

  const nextVideoIndex = (currentVideoIndex + 1) % queueVideos.length
  const nextVideo = queueVideos[nextVideoIndex] || null

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-500">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-white font-bold text-sm uppercase">ON AIR</span>
            </div>
            <span className="text-white/40">|</span>
            <h1 className="text-lg font-bold text-white">{settings?.site_name || 'TRUMPETER TV'} – 24/7</h1>
          </div>
          <div className="flex items-center gap-2">
            {/* Voice Command Button */}
            {voiceSupported && (
              <button 
                onClick={startVoiceCommand}
                className={`p-2 rounded-full ${voiceListening ? 'bg-red-500 animate-pulse' : 'bg-white/20'}`}
                title="Voice Commands"
              >
                <Mic className="w-5 h-5 text-white" />
              </button>
            )}
            {/* Share Button */}
            <button onClick={handleShare} className="p-2 bg-white/20 rounded-full" title="Share">
              <Share2 className="w-5 h-5 text-white" />
            </button>
            {/* Notification Button */}
            <button 
              onClick={requestNotificationPermission}
              className={`p-2 rounded-full ${notificationPermission === 'granted' ? 'bg-green-500' : 'bg-white/20'}`}
              title="Notifications"
            >
              <Bell className="w-5 h-5 text-white" />
            </button>
            <button onClick={() => setSideMenuOpen(!sideMenuOpen)} className="p-2 bg-white/20 rounded-full">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      {showNotification && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-gray-800 text-white px-4 py-2 rounded-lg shadow-lg">
          {notificationMessage}
        </div>
      )}

      {/* Side Menu */}
      {sideMenuOpen && (
        <>
          <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setSideMenuOpen(false)} />
          <div className="fixed top-0 right-0 h-full w-80 bg-white shadow-2xl z-50 overflow-y-auto">
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold">Menu</h2>
                <button onClick={() => setSideMenuOpen(false)} className="p-2 text-2xl">&times;</button>
              </div>
              <nav className="space-y-1">
                <Link href="/" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Home</Link>
                <Link href="/learn" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg text-blue-600 font-semibold">💎 PreciousMinds</Link>
                <Link href="/watch" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">All Videos</Link>
                <Link href="/music" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Music</Link>
                <Link href="/community" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Community</Link>
                <Link href="/admin/dashboard" onClick={() => setSideMenuOpen(false)} className="block px-4 py-3 hover:bg-blue-50 rounded-lg">Admin</Link>
              </nav>
              <div className="mt-6 pt-4 border-t">
                <p className="text-xs text-gray-400 mb-2">UP NEXT</p>
                <p className="font-medium">{nextVideo?.title}</p>
              </div>
              {/* Quick Stats */}
              <div className="mt-6 pt-4 border-t">
                <p className="text-xs text-gray-400 mb-2">YOUR GROWTH TRACKER</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-blue-50 p-2 rounded">
                    <p className="text-lg font-bold text-blue-600">{growthStats.services}</p>
                    <p className="text-xs text-gray-500">Services</p>
                  </div>
                  <div className="bg-green-50 p-2 rounded">
                    <p className="text-lg font-bold text-green-600">{growthStats.notes}</p>
                    <p className="text-xs text-gray-500">Notes</p>
                  </div>
                  <div className="bg-yellow-50 p-2 rounded">
                    <p className="text-lg font-bold text-yellow-600">{growthStats.prayers}</p>
                    <p className="text-xs text-gray-500">Prayers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Main Content */}
      <div className="flex-1 p-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Video Player */}
          <div className="lg:col-span-2 space-y-4">
            {/* Source Tabs */}
            <div className="flex gap-2 mb-2">
              <button
                onClick={() => setSourceTab('youtube')}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                  sourceTab === 'youtube' 
                    ? 'bg-red-600 text-white' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                YouTube
              </button>
              <button
                onClick={() => setSourceTab('facebook')}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                  sourceTab === 'facebook' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Facebook Live
              </button>
            </div>

            <div className="relative bg-black rounded-xl overflow-hidden shadow-lg" style={{ paddingTop: '56.25%' }}>
              {/* Logo Watermark */}
              <div className="absolute top-4 left-4 z-10 opacity-70">
                <Logo size="sm" variant="light" />
              </div>

              {/* Facebook Live iframe */}
              {sourceTab === 'facebook' && settings?.facebook_live_url ? (
                <iframe
                  key="facebook-live"
                  className="absolute inset-0 w-full h-full"
                  src={getFacebookEmbedUrl(settings.facebook_live_url)}
                  title="Facebook Live"
                  frameBorder="0"
                  allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                  allowFullScreen
                />
              ) : sourceTab === 'youtube' && currentVideo && isYouTubeVideo ? (
                <iframe
                  key={videoKey}
                  className="absolute inset-0 w-full h-full"
                  src={getYouTubeEmbedUrl(currentVideo)}
                  title={currentVideo.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                  <div className="text-center">
                    <p className="text-white/60 text-lg">
                      {sourceTab === 'facebook' ? 'No Facebook Live URL configured' : 'No video in queue'}
                    </p>
                    <p className="text-white/40 text-sm mt-1">
                      {sourceTab === 'facebook' ? 'Add Facebook URL in Admin settings' : 'Add videos in Admin'}
                    </p>
                  </div>
                </div>
              )}

              {/* Live Badge */}
              {currentVideo && sourceTab === 'youtube' && (
                <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-red-600 px-3 py-1.5 rounded-lg">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="text-white text-xs font-bold uppercase">LIVE</span>
                </div>
              )}

              {/* Facebook Live Badge */}
              {sourceTab === 'facebook' && settings?.facebook_live_url && (
                <div className="absolute top-4 right-4 z-10 flex items-center gap-1 bg-blue-600 px-2 py-0.5 rounded">
                  <span className="text-white text-xs font-medium">FB LIVE</span>
                </div>
              )}

              {/* Unmute Button */}
              {sourceTab === 'youtube' && currentVideo && isMuted && (
                <button
                  onClick={() => setIsMuted(false)}
                  className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 bg-black/80 hover:bg-black px-6 py-3 rounded-full text-white font-medium flex items-center gap-2"
                >
                  🔇 Click to Unmute
                </button>
              )}
            </div>

            {/* Video Info */}
            <div className="bg-white rounded-xl p-4 shadow-sm">
              {sourceTab === 'facebook' ? (
                <>
                  <p className="text-xs text-gray-400 mb-1">Facebook Live Stream</p>
                  <h2 className="text-xl font-bold text-gray-800">{settings?.site_name || 'TRUMPETER TV'} - Live</h2>
                </>
              ) : (
                <>
                  <p className="text-xs text-gray-400 mb-1">
                    {currentVideoIndex + 1} of {queueVideos.length}
                  </p>
                  <h2 className="text-xl font-bold text-gray-800">{currentVideo?.title}</h2>
                  {nextVideo && (
                    <p className="text-sm text-gray-500 mt-2">
                      Up Next: <span className="font-medium text-gray-700">{nextVideo.title}</span>
                    </p>
                  )}
                </>
              )}
            </div>

            {/* Features Tabs */}
            <Tabs defaultValue="chat" className="w-full">
              <TabsList className="grid w-full grid-cols-5 bg-white border mb-2">
                <TabsTrigger value="chat" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs p-2">
                  <MessageCircle className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="prayer" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs p-2">
                  <Heart className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="notes" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs p-2">
                  <BookOpen className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="map" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs p-2">
                  <Globe className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="tools" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-xs p-2">
                  <Users className="w-4 h-4" />
                </TabsTrigger>
              </TabsList>

              {/* Live Chat Tab */}
              <TabsContent value="chat">
                <Card className="bg-white">
                  <CardHeader className="p-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <MessageCircle className="w-4 h-4" /> Live Chat
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0">
                    <div className="h-40 overflow-y-auto space-y-2 mb-3 bg-gray-50 p-2 rounded">
                      {chatMessages.map((msg, i) => (
                        <div key={i} className="text-sm">
                          <span className="font-medium text-blue-600">{msg.name}:</span>{' '}
                          <span className="text-gray-700">{msg.message}</span>
                          <span className="text-xs text-gray-400 ml-2">{msg.time}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Your name"
                        value={chatName}
                        onChange={(e) => setChatName(e.target.value)}
                        className="w-24"
                      />
                      <Input
                        placeholder="Message..."
                        value={chatMessage}
                        onChange={(e) => setChatMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendChat()}
                        className="flex-1"
                      />
                      <Button onClick={handleSendChat} size="icon">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Prayer Wall Tab */}
              <TabsContent value="prayer">
                <Card className="bg-white">
                  <CardHeader className="p-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Heart className="w-4 h-4" /> Prayer Wall
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0">
                    <div className="h-32 overflow-y-auto space-y-2 mb-3 bg-gray-50 p-2 rounded">
                      {prayerRequests.map((pr, i) => (
                        <div key={i} className="text-sm p-2 bg-white rounded border">
                          <p className="text-gray-700">{pr.request}</p>
                          <p className="text-xs text-gray-400 mt-1">- {pr.name} from {pr.location}</p>
                        </div>
                      ))}
                    </div>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Your name"
                          value={prayerName}
                          onChange={(e) => setPrayerName(e.target.value)}
                          className="w-24"
                        />
                        <Input
                          placeholder="Your location"
                          value={prayerLocation}
                          onChange={(e) => setPrayerLocation(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Your prayer request..."
                          value={prayerText}
                          onChange={(e) => setPrayerText(e.target.value)}
                          className="flex-1"
                        />
                        <Button onClick={handlePrayerSubmit} size="icon" className="bg-red-500 hover:bg-red-600">
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Sermon Notes Tab */}
              <TabsContent value="notes">
                <Card className="bg-white">
                  <CardHeader className="p-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <BookOpen className="w-4 h-4" /> Sermon Notes
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0">
                    <Textarea
                      placeholder="Take notes during the sermon..."
                      value={sermonNotes}
                      onChange={(e) => setSermonNotes(e.target.value)}
                      className="min-h-[120px] mb-2"
                    />
                    <div className="flex gap-2">
                      <Button onClick={() => { handleSaveNotes(); updateGrowth('notes'); }} className="flex-1">
                        <Check className="w-4 h-4 mr-2" /> Save Notes
                      </Button>
                      <Button onClick={handleDownload} variant="outline" className="flex-1">
                        <Download className="w-4 h-4 mr-2" /> Download
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Global Viewers Map Tab */}
              <TabsContent value="map">
                <Card className="bg-white">
                  <CardHeader className="p-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Globe className="w-4 h-4" /> Global Viewers ({totalViewers})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0">
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {viewerLocations.map((loc, i) => (
                        <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-red-500" />
                            <span className="text-sm">{loc.city}, {loc.country}</span>
                          </div>
                          <span className="text-sm font-medium text-blue-600">{loc.count} viewers</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tools Tab (Altar Call, Language, etc.) */}
              <TabsContent value="tools">
                <div className="grid grid-cols-2 gap-2">
                  {/* Altar Call */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={() => setAltarCallOpen(true)}>
                    <CardContent className="p-3 text-center">
                      <Heart className="w-6 h-6 mx-auto mb-1 text-red-500" />
                      <p className="text-xs font-medium">Altar Call</p>
                    </CardContent>
                  </Card>
                  
                  {/* Language Translation */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={() => setTranslationEnabled(!translationEnabled)}>
                    <CardContent className="p-3 text-center">
                      <Languages className="w-6 h-6 mx-auto mb-1 text-blue-500" />
                      <p className="text-xs font-medium">Translate</p>
                      {translationEnabled && (
                        <select 
                          value={selectedLanguage}
                          onChange={(e) => setSelectedLanguage(e.target.value)}
                          className="text-xs mt-1 w-full"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value="en">English</option>
                          <option value="es">Spanish</option>
                          <option value="fr">French</option>
                          <option value="pt">Portuguese</option>
                          <option value="yo">Yoruba</option>
                          <option value="ig">Igbo</option>
                          <option value="ha">Hausa</option>
                          <option value="sw">Swahili</option>
                        </select>
                      )}
                    </CardContent>
                  </Card>

                  {/* SMS Prayer Line */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={smsPrayerLine}>
                    <CardContent className="p-3 text-center">
                      <Phone className="w-6 h-6 mx-auto mb-1 text-green-500" />
                      <p className="text-xs font-medium">SMS Prayer</p>
                    </CardContent>
                  </Card>

                  {/* Bible App */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={openBibleApp}>
                    <CardContent className="p-3 text-center">
                      <BookOpen className="w-6 h-6 mx-auto mb-1 text-purple-500" />
                      <p className="text-xs font-medium">Bible App</p>
                    </CardContent>
                  </Card>

                  {/* Download */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={handleDownload}>
                    <CardContent className="p-3 text-center">
                      <Download className="w-6 h-6 mx-auto mb-1 text-orange-500" />
                      <p className="text-xs font-medium">Download</p>
                    </CardContent>
                  </Card>

                  {/* Share */}
                  <Card className="bg-white cursor-pointer hover:shadow-md transition-shadow" onClick={handleShare}>
                    <CardContent className="p-3 text-center">
                      <Share2 className="w-6 h-6 mx-auto mb-1 text-indigo-500" />
                      <p className="text-xs font-medium">Share</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Queue Sidebar */}
          <div className="bg-white rounded-xl p-4 shadow-sm h-fit">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <span>📺</span> Playlist
              <span className="text-xs font-normal text-gray-400">({queueVideos.length})</span>
            </h3>
            <div className="space-y-1 max-h-[400px] overflow-y-auto">
              {queueVideos.length > 0 ? (
                queueVideos.map((video, index) => (
                  <div
                    key={video.id}
                    className={`p-3 rounded-lg flex items-center gap-3 ${
                      index === currentVideoIndex ? 'bg-blue-600 text-white' : 'bg-gray-50'
                    }`}
                  >
                    <span className={`w-6 text-center text-sm ${
                      index === currentVideoIndex ? 'text-white' : 'text-gray-400'
                    }`}>
                      {index === currentVideoIndex ? '▶' : index + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate text-sm">{video.title}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-400">No videos</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Altar Call Modal */}
      {altarCallOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">🙏 Altar Call</h3>
              <button onClick={() => setAltarCallOpen(false)} className="p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            {altarCallSubmitted ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-lg font-medium text-gray-800">Thank you for your decision!</p>
                <p className="text-gray-500 mt-2">A pastor will contact you soon.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-gray-600">Make a decision for Christ today. Submit your info and a pastor will reach out.</p>
                <Input
                  placeholder="Your Name *"
                  value={altarCallName}
                  onChange={(e) => setAltarCallName(e.target.value)}
                />
                <Input
                  placeholder="Phone Number (optional)"
                  value={altarCallPhone}
                  onChange={(e) => setAltarCallPhone(e.target.value)}
                />
                <Button onClick={handleAltarCall} className="w-full bg-blue-600 hover:bg-blue-700">
                  Submit Altar Call
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white py-4 border-t mt-auto">
        <div className="max-w-6xl mx-auto px-4 text-center text-gray-500 text-sm">
          © {new Date().getFullYear()} {settings?.site_name || 'TRUMPETER TV'}. 24/7 Christian Broadcasting.
        </div>
      </footer>
    </div>
  )
}
