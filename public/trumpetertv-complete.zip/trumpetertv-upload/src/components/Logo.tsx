'use client'

interface LogoProps {
  size?: 'sm' | 'md' | 'lg'
  variant?: 'light' | 'dark'
}

export default function Logo({ size = 'md', variant = 'dark' }: LogoProps) {
  const sizes = {
    sm: { width: '36px', height: '36px', fontSize: '12px', textFont: '14px', subFont: '8px' },
    md: { width: '48px', height: '48px', fontSize: '16px', textFont: '18px', subFont: '10px' },
    lg: { width: '60px', height: '60px', fontSize: '20px', textFont: '24px', subFont: '12px' }
  }

  const colors = {
    light: { bg: 'bg-white', text: 'text-gray-900', sub: 'text-gray-600' },
    dark: { bg: 'bg-gray-900', text: 'text-white', sub: 'text-gray-300' }
  }

  return (
    <div className="flex items-center gap-2">
      {/* Trumpet Icon */}
      <div 
        className={`${colors[variant].bg} rounded-lg flex items-center justify-center shadow-lg`}
        style={{ width: sizes[size].width, height: sizes[size].height }}
      >
        <svg 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke={variant === 'light' ? '#1f2937' : '#ffffff'}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ width: sizes[size].fontSize, height: sizes[size].fontSize }}
        >
          <path d="M11 5L6 9H3v6h3l5 4V5z" />
          <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
          <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
        </svg>
      </div>
      <div className="flex flex-col">
        <span 
          className={`font-bold ${variant === 'light' ? 'text-white' : 'text-gray-900'}`}
          style={{ fontSize: sizes[size].textFont, lineHeight: 1.1 }}
        >
          TRUMPETER
        </span>
        <span 
          className={`font-medium tracking-wider ${variant === 'light' ? 'text-white/80' : 'text-gray-500'}`}
          style={{ fontSize: sizes[size].subFont, letterSpacing: '0.1em' }}
        >
          TV
        </span>
      </div>
    </div>
  )
}
