'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { 
  Video, Settings, Slide, PrayerRequest, Testimony,
  Course, Lesson, User, LessonProgress, Badge, LeaderboardEntry,
  CourseCategory
} from '@/lib/data'

interface DataContextType {
  // TV App
  settings: Settings | null
  slides: Slide[]
  videos: Video[]
  prayerRequests: PrayerRequest[]
  testimonies: Testimony[]
  isLoggedIn: boolean
  loading: boolean
  updateSettings: (settings: Partial<Settings>) => void
  addSlide: (slide: Slide) => void
  removeSlide: (id: string) => void
  addVideo: (video: Video) => void
  removeVideo: (id: string) => void
  login: (email: string, password: string) => boolean
  logout: () => void
  addPrayerRequest: (request: Omit<PrayerRequest, 'id' | 'createdAt'>) => void
  addTestimony: (testimony: Omit<Testimony, 'id' | 'createdAt'>) => void
  
  // PreciousMinds Learning
  currentUser: User | null
  courses: Course[]
  lessons: Lesson[]
  userProgress: LessonProgress[]
  badges: Badge[]
  leaderboard: LeaderboardEntry[]
  
  // Learning Actions
  startLesson: (lessonId: string) => void
  completeStep: (lessonId: string, stepId: string, isCorrect: boolean) => void
  completeLesson: (lessonId: string) => void
  getUserXP: () => number
  getUserLevel: () => number
  getStreak: () => number
  getLessonProgress: (lessonId: string) => LessonProgress | undefined
  getCourseProgress: (courseId: string) => number
  addXP: (amount: number) => void
  updateStreak: () => void
  awardBadge: (badgeId: string) => void
}

const DataContext = createContext<DataContextType | undefined>(undefined)

// Login Credentials
const LOGIN_EMAIL = 'admin@trumpetertv.com'
const LOGIN_PASSWORD = 'TrumpeterTV2024!'

// Sample Badges
const defaultBadges: Badge[] = [
  { id: 'first-lesson', name: 'First Steps', description: 'Complete your first lesson', icon: '🎯', xpReward: 50, requirement: { type: 'lessons', value: 1 }, rarity: 'common' },
  { id: 'streak-3', name: 'On Fire', description: '3 day learning streak', icon: '🔥', xpReward: 100, requirement: { type: 'streak', value: 3 }, rarity: 'common' },
  { id: 'streak-7', name: 'Week Warrior', description: '7 day learning streak', icon: '⚔️', xpReward: 250, requirement: { type: 'streak', value: 7 }, rarity: 'rare' },
  { id: 'streak-30', name: 'Monthly Master', description: '30 day learning streak', icon: '👑', xpReward: 1000, requirement: { type: 'streak', value: 30 }, rarity: 'legendary' },
  { id: 'xp-1000', name: 'Knowledge Seeker', description: 'Earn 1000 XP', icon: '⭐', xpReward: 100, requirement: { type: 'xp', value: 1000 }, rarity: 'common' },
  { id: 'xp-5000', name: 'Scholar', description: 'Earn 5000 XP', icon: '📚', xpReward: 500, requirement: { type: 'xp', value: 5000 }, rarity: 'rare' },
  { id: 'perfect-10', name: 'Perfectionist', description: 'Get 10 perfect scores', icon: '💯', xpReward: 300, requirement: { type: 'perfect-score', value: 10 }, rarity: 'epic' },
  { id: 'courses-5', name: 'Polymath', description: 'Complete 5 courses', icon: '🎓', xpReward: 500, requirement: { type: 'courses', value: 5 }, rarity: 'epic' },
]

// Sample Courses with Lessons
const defaultCourses: Course[] = [
  {
    id: 'math-foundations',
    title: 'Foundations of Algebra',
    description: 'Strengthen your math fundamentals with interactive lessons',
    category: 'math-foundations',
    lessons: ['lesson-1', 'lesson-2', 'lesson-3'],
    totalXP: 300,
    difficulty: 'beginner',
    order: 1,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'logic-101',
    title: 'Logical Reasoning',
    description: 'Sharpen your mind with logical puzzles and reasoning',
    category: 'logic',
    lessons: ['lesson-4', 'lesson-5'],
    totalXP: 200,
    difficulty: 'beginner',
    order: 2,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'programming-basics',
    title: 'Thinking in Code',
    description: 'Learn the fundamentals of programming logic',
    category: 'programming',
    lessons: ['lesson-6', 'lesson-7', 'lesson-8'],
    totalXP: 350,
    difficulty: 'beginner',
    order: 3,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'science-basics',
    title: 'Scientific Thinking',
    description: 'Explore the scientific method and discoveries',
    category: 'science',
    lessons: ['lesson-9', 'lesson-10'],
    totalXP: 200,
    difficulty: 'beginner',
    order: 4,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
]

// Sample Lessons with Interactive Steps
const defaultLessons: Lesson[] = [
  {
    id: 'lesson-1',
    courseId: 'math-foundations',
    title: 'What is a Variable?',
    description: 'Learn how variables store values',
    order: 1,
    xpReward: 100,
    estimatedMinutes: 10,
    isPublished: true,
    steps: [
      {
        id: 'step-1-1',
        type: 'text',
        order: 1,
        content: {
          title: 'Introduction to Variables',
          text: 'In math and programming, a **variable** is like a container that holds a value. Think of it as a labeled box where you can store numbers, text, or other data.'
        }
      },
      {
        id: 'step-1-2',
        type: 'image',
        order: 2,
        content: {
          title: 'Visual: Box Analogy',
          text: 'Imagine a box labeled "age" containing the number 25.',
          imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTUwIiBoZWlnaHQ9IjEwMCIgeD0iNzUiIHk9IjUwIiBmaWxsPSIjNEE5MEUyIiBzdHJva2U9IiMyNTYzRUIiIHN0cm9rZS13aWR0aD0iMyIgcng9IjEwIi8+PHRleHQgeD0iMTUwIiB5PSIzMCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0IiBmaWxsPSIjMzMzIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5hZ2U8L3RleHQ+PHRleHQgeD0iMTUwIiB5PSI5MCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjI0IiBmaWxsPSIjZmZmIiBmb250LXdlaWdodD0iYm9sZCIgdGV4dC1hbmNob3I9Im1pZGRsZSI+MjU8L3RleHQ+PC9zdmc+'
        }
      },
      {
        id: 'step-1-3',
        type: 'interactive',
        order: 3,
        content: {
          title: 'Try It: Create a Variable',
          interactiveType: 'build',
          interactiveConfig: {
            elementType: 'card',
            elements: [
              { id: 'box1', content: 'x = 5', color: '#4A90E2' },
              { id: 'box2', content: 'name = "John"', color: '#50C878' },
              { id: 'box3', content: 'score = 100', color: '#FFB347' }
            ],
            feedback: { correct: 'Great! You created a variable!', incorrect: 'Try again!' }
          }
        }
      },
      {
        id: 'step-1-4',
        type: 'multiple-choice',
        order: 4,
        content: {
          question: 'What does the variable `age = 25` store?',
          options: [
            { id: 'a', text: 'The text "age"', isCorrect: false },
            { id: 'b', text: 'The number 25', isCorrect: true },
            { id: 'c', text: 'The word "25"', isCorrect: false },
            { id: 'd', text: 'Nothing', isCorrect: false }
          ],
          explanation: 'The variable `age` stores the numeric value 25. We can use `age` later to refer to this value.',
          hint: 'Variables store the value on the right side of the equals sign.'
        }
      },
      {
        id: 'step-1-5',
        type: 'fill-blank',
        order: 5,
        content: {
          title: 'Fill in the Blank',
          text: 'Complete the variable assignment:',
          blanks: [
            { id: 'blank1', correctAnswer: 'x', placeholder: 'variable name' }
          ]
        }
      },
      {
        id: 'step-1-6',
        type: 'math',
        order: 6,
        content: {
          title: 'Math Notation',
          text: 'In algebra, we write variables like this:',
          latex: 'x = 5 \\implies x + 3 = 8',
          mathDisplay: 'block'
        }
      },
      {
        id: 'step-1-7',
        type: 'code',
        order: 7,
        content: {
          title: 'See it in Code',
          text: 'Here\'s how variables look in Python:',
          code: '# Create a variable\nage = 25\nname = "John"\nscore = 95.5\n\n# Use the variables\nprint(f"{name} is {age} years old")\nprint(f"Score: {score}")',
          language: 'python'
        }
      }
    ]
  },
  {
    id: 'lesson-2',
    courseId: 'math-foundations',
    title: 'Arithmetic Operations',
    description: 'Learn basic math operations with variables',
    order: 2,
    xpReward: 100,
    estimatedMinutes: 12,
    isPublished: true,
    steps: [
      {
        id: 'step-2-1',
        type: 'text',
        order: 1,
        content: {
          title: 'Basic Operations',
          text: 'Variables can be used in arithmetic operations: addition (+), subtraction (-), multiplication (*), and division (/).'
        }
      },
      {
        id: 'step-2-2',
        type: 'slider',
        order: 2,
        content: {
          title: 'Interactive: Adjust Values',
          text: 'Move the slider to see how the result changes:',
          sliderConfig: {
            min: 0,
            max: 100,
            step: 1,
            defaultValue: 50,
            unit: '',
            label: 'x value'
          }
        }
      },
      {
        id: 'step-2-3',
        type: 'drag-order',
        order: 3,
        content: {
          title: 'Order of Operations',
          text: 'Drag to arrange the correct order of operations (PEMDAS):',
          sortItems: [
            { id: 'p', content: 'Parentheses ()', correctPosition: 1 },
            { id: 'e', content: 'Exponents ^', correctPosition: 2 },
            { id: 'm', content: 'Multiplication *', correctPosition: 3 },
            { id: 'd', content: 'Division /', correctPosition: 4 },
            { id: 'a', content: 'Addition +', correctPosition: 5 },
            { id: 's', content: 'Subtraction -', correctPosition: 6 }
          ],
          correctOrder: ['p', 'e', 'm', 'd', 'a', 's']
        }
      },
      {
        id: 'step-2-4',
        type: 'multiple-choice',
        order: 4,
        content: {
          question: 'What is the result of `2 + 3 * 4`?',
          options: [
            { id: 'a', text: '20', isCorrect: false },
            { id: 'b', text: '14', isCorrect: true },
            { id: 'c', text: '24', isCorrect: false },
            { id: 'd', text: '9', isCorrect: false }
          ],
          explanation: 'Following order of operations, we do multiplication first: 3 * 4 = 12, then add: 2 + 12 = 14.',
          hint: 'Remember: multiplication comes before addition!'
        }
      },
      {
        id: 'step-2-5',
        type: 'math',
        order: 5,
        content: {
          title: 'Mathematical Proof',
          text: 'Here\'s the step-by-step calculation:',
          latex: '2 + 3 \\times 4 = 2 + 12 = 14',
          mathDisplay: 'block'
        }
      },
      {
        id: 'step-2-6',
        type: 'simulation',
        order: 6,
        content: {
          title: 'Physics Simulation',
          text: 'See how variables work in a real simulation. Adjust gravity and watch the ball fall!',
          simulationType: 'physics',
          simulationConfig: {
            gravity: 9.8,
            objects: [
              { id: 'ball', type: 'circle', x: 150, y: 50, radius: 20, color: '#4A90E2' }
            ]
          }
        }
      }
    ]
  },
  {
    id: 'lesson-3',
    courseId: 'math-foundations',
    title: 'Coordinate Plane',
    description: 'Understand x, y coordinates on a graph',
    order: 3,
    xpReward: 100,
    estimatedMinutes: 15,
    isPublished: true,
    steps: [
      {
        id: 'step-3-1',
        type: 'text',
        order: 1,
        content: {
          title: 'The Coordinate Plane',
          text: 'A coordinate plane has two axes: the x-axis (horizontal) and y-axis (vertical). Every point is described by coordinates (x, y).'
        }
      },
      {
        id: 'step-3-2',
        type: 'graph',
        order: 2,
        content: {
          title: 'Interactive Graph',
          text: 'Click on the graph to place points. Watch the coordinates change!',
          graphConfig: {
            type: 'interactive',
            xAxis: { label: 'X', min: -10, max: 10 },
            yAxis: { label: 'Y', min: -10, max: 10 },
            interactiveMode: 'plot'
          }
        }
      },
      {
        id: 'step-3-3',
        type: 'drag-drop',
        order: 3,
        content: {
          title: 'Match Points to Coordinates',
          text: 'Drag each point to its correct location:',
          dragItems: [
            { id: 'p1', content: '(3, 2)', type: 'text', correctZone: 'zone-1' },
            { id: 'p2', content: '(-2, 4)', type: 'text', correctZone: 'zone-2' },
            { id: 'p3', content: '(0, -3)', type: 'text', correctZone: 'zone-3' }
          ],
          dropZones: [
            { id: 'zone-1', label: 'Quadrant I' },
            { id: 'zone-2', label: 'Quadrant II' },
            { id: 'zone-3', label: 'Y-axis' }
          ]
        }
      },
      {
        id: 'step-3-4',
        type: 'multiple-choice',
        order: 4,
        content: {
          question: 'Which quadrant is point (-3, -5) located in?',
          options: [
            { id: 'a', text: 'Quadrant I', isCorrect: false },
            { id: 'b', text: 'Quadrant II', isCorrect: false },
            { id: 'c', text: 'Quadrant III', isCorrect: true },
            { id: 'd', text: 'Quadrant IV', isCorrect: false }
          ],
          explanation: 'Quadrant III has negative x and negative y values.',
          hint: 'Both coordinates are negative.'
        }
      }
    ]
  },
  {
    id: 'lesson-4',
    courseId: 'logic-101',
    title: 'Introduction to Logic',
    description: 'Learn the basics of logical reasoning',
    order: 1,
    xpReward: 100,
    estimatedMinutes: 10,
    isPublished: true,
    steps: [
      {
        id: 'step-4-1',
        type: 'text',
        order: 1,
        content: {
          title: 'What is Logic?',
          text: 'Logic is the study of reasoning. It helps us determine if an argument is valid or invalid, true or false.'
        }
      },
      {
        id: 'step-4-2',
        type: 'multiple-choice',
        order: 2,
        content: {
          question: 'If "All birds can fly" and "Penguins are birds", what can we conclude?',
          options: [
            { id: 'a', text: 'Penguins can fly', isCorrect: false, feedback: 'This is valid logic, but the premise is false!' },
            { id: 'b', text: 'Penguins cannot fly', isCorrect: false, feedback: 'This is true in reality, but doesn\'t follow from the premises' },
            { id: 'c', text: 'The first statement is false', isCorrect: true, feedback: 'Correct! Not all birds can fly.' },
            { id: 'd', text: 'Nothing', isCorrect: false }
          ],
          explanation: 'Logic helps us identify when premises lead to false conclusions. The statement "All birds can fly" is actually false.',
          hint: 'Think about which birds cannot fly...'
        }
      },
      {
        id: 'step-4-3',
        type: 'matching',
        order: 3,
        content: {
          title: 'Match Logical Terms',
          text: 'Connect each logical term with its definition:',
          matchingPairs: [
            { left: { id: 'l1', content: 'Premise' }, right: { id: 'r1', content: 'A starting statement assumed true' } },
            { left: { id: 'l2', content: 'Conclusion' }, right: { id: 'r2', content: 'A statement derived from premises' } },
            { left: { id: 'l3', content: 'Argument' }, right: { id: 'r3', content: 'Premises leading to a conclusion' } }
          ]
        }
      }
    ]
  },
  {
    id: 'lesson-5',
    courseId: 'logic-101',
    title: 'Truth and Lies Puzzles',
    description: 'Solve classic logic puzzles',
    order: 2,
    xpReward: 100,
    estimatedMinutes: 15,
    isPublished: true,
    steps: [
      {
        id: 'step-5-1',
        type: 'text',
        order: 1,
        content: {
          title: 'Knights and Knaves',
          text: 'Imagine an island where knights always tell the truth and knaves always lie. Can you figure out who is who?'
        }
      },
      {
        id: 'step-5-2',
        type: 'interactive',
        order: 2,
        content: {
          title: 'Interactive Puzzle',
          interactiveType: 'click',
          interactiveConfig: {
            elementType: 'card',
            elements: [
              { id: 'person1', content: 'Person A says: "We are both knaves"', color: '#4A90E2' },
              { id: 'person2', content: 'Person B says: "Person A is a knight"', color: '#50C878' }
            ],
            feedback: { correct: 'Correct! Think through the logic.', incorrect: 'Try again!' }
          }
        }
      },
      {
        id: 'step-5-3',
        type: 'multiple-choice',
        order: 3,
        content: {
          question: 'If Person A is a knight (truth-teller), what happens when he says "We are both knaves"?',
          options: [
            { id: 'a', text: 'It would be true, so both are knaves - contradiction!', isCorrect: true },
            { id: 'b', text: 'It would be false, so A is a knave - contradiction!', isCorrect: false },
            { id: 'c', text: 'Nothing special happens', isCorrect: false }
          ],
          explanation: 'A knight cannot say "We are both knaves" because it would be a lie. So A must be a knave, making the statement false, meaning at least one is a knight (B).',
          hint: 'A knight always tells the truth. Can a knight claim to be a knave?'
        }
      }
    ]
  },
  {
    id: 'lesson-6',
    courseId: 'programming-basics',
    title: 'Thinking in Code',
    description: 'Learn how to think like a programmer',
    order: 1,
    xpReward: 100,
    estimatedMinutes: 12,
    isPublished: true,
    steps: [
      {
        id: 'step-6-1',
        type: 'text',
        order: 1,
        content: {
          title: 'What is Programming?',
          text: 'Programming is giving a computer step-by-step instructions to solve a problem. Think of it like a recipe for cooking!'
        }
      },
      {
        id: 'step-6-2',
        type: 'sorting',
        order: 2,
        content: {
          title: 'Arrange the Algorithm',
          text: 'Put these steps in the correct order to make a peanut butter sandwich:',
          sortItems: [
            { id: 's1', content: 'Get bread', correctPosition: 1 },
            { id: 's2', content: 'Open peanut butter jar', correctPosition: 2 },
            { id: 's3', content: 'Spread peanut butter on bread', correctPosition: 3 },
            { id: 's4', content: 'Put bread slices together', correctPosition: 4 },
            { id: 's5', content: 'Eat sandwich', correctPosition: 5 }
          ],
          correctOrder: ['s1', 's2', 's3', 's4', 's5']
        }
      },
      {
        id: 'step-6-3',
        type: 'code',
        order: 3,
        content: {
          title: 'Your First Code',
          text: 'Here\'s how that algorithm looks in Python:',
          code: '# Making a sandwich - algorithm\nprint("Step 1: Get bread")\nprint("Step 2: Open peanut butter")\nprint("Step 3: Spread on bread")\nprint("Step 4: Put together")\nprint("Step 5: Enjoy!")',
          language: 'python'
        }
      },
      {
        id: 'step-6-4',
        type: 'code-execute',
        order: 4,
        content: {
          title: 'Try It Yourself!',
          text: 'Write code to print your name:',
          codeQuestion: 'Write code that prints "Hello, [your name]!"',
          starterCode: 'print("Hello, World!")',
          language: 'python',
          expectedOutput: 'Hello, World!'
        }
      }
    ]
  },
  {
    id: 'lesson-7',
    courseId: 'programming-basics',
    title: 'Variables in Python',
    description: 'Create and use variables in programming',
    order: 2,
    xpReward: 100,
    estimatedMinutes: 10,
    isPublished: true,
    steps: [
      {
        id: 'step-7-1',
        type: 'text',
        order: 1,
        content: {
          title: 'Variables in Code',
          text: 'Variables in programming are like labeled boxes that store data. You can change what\'s inside, and use the variable name to access the value.'
        }
      },
      {
        id: 'step-7-2',
        type: 'code',
        order: 2,
        content: {
          title: 'Creating Variables',
          text: 'In Python, creating a variable is simple:',
          code: '# Create variables\nname = "Alice"\nage = 25\nheight = 5.6\nis_student = True\n\n# Print variables\nprint(name)\nprint(age)\nprint(f"{name} is {age} years old")',
          language: 'python'
        }
      },
      {
        id: 'step-7-3',
        type: 'multiple-choice',
        order: 3,
        content: {
          question: 'What will `print(age + 5)` output if `age = 20`?',
          options: [
            { id: 'a', text: 'age + 5', isCorrect: false },
            { id: 'b', text: '25', isCorrect: true },
            { id: 'c', text: '205', isCorrect: false },
            { id: 'd', text: 'Error', isCorrect: false }
          ],
          explanation: 'The variable `age` stores 20. When we add 5, we get 25.',
          hint: 'Variables are replaced by their values when used.'
        }
      },
      {
        id: 'step-7-4',
        type: 'code-execute',
        order: 4,
        content: {
          title: 'Practice: Create Variables',
          text: 'Create a variable called `score` with value 100 and print it:',
          starterCode: '# Create variable score = 100\n# Print it',
          language: 'python',
          expectedOutput: '100'
        }
      }
    ]
  },
  {
    id: 'lesson-8',
    courseId: 'programming-basics',
    title: 'Conditionals',
    description: 'Make decisions in code with if/else',
    order: 3,
    xpReward: 150,
    estimatedMinutes: 15,
    isPublished: true,
    steps: [
      {
        id: 'step-8-1',
        type: 'text',
        order: 1,
        content: {
          title: 'Making Decisions',
          text: 'Programs often need to make decisions based on conditions. We use `if`, `elif`, and `else` statements.'
        }
      },
      {
        id: 'step-8-2',
        type: 'interactive',
        order: 2,
        content: {
          title: 'Flowchart: Decision Making',
          interactiveType: 'click',
          interactiveConfig: {
            elementType: 'node',
            elements: [
              { id: 'start', content: 'Start', color: '#4A90E2' },
              { id: 'condition', content: 'Is score >= 60?', color: '#FFB347' },
              { id: 'yes', content: 'Print "Pass"', color: '#50C878' },
              { id: 'no', content: 'Print "Fail"', color: '#FF6B6B' }
            ],
            correctSequence: ['start', 'condition', 'yes'],
            feedback: { correct: 'Flow understood!', incorrect: 'Follow the flow!' }
          }
        }
      },
      {
        id: 'step-8-3',
        type: 'code',
        order: 3,
        content: {
          title: 'If/Else Syntax',
          text: 'Here\'s how to write conditionals in Python:',
          code: 'score = 75\n\nif score >= 90:\n    print("Grade: A")\nelif score >= 80:\n    print("Grade: B")\nelif score >= 70:\n    print("Grade: C")\nelif score >= 60:\n    print("Grade: D")\nelse:\n    print("Grade: F")',
          language: 'python'
        }
      },
      {
        id: 'step-8-4',
        type: 'multiple-choice',
        order: 4,
        content: {
          question: 'What grade will be printed if score = 85?',
          options: [
            { id: 'a', text: 'A', isCorrect: false },
            { id: 'b', text: 'B', isCorrect: true },
            { id: 'c', text: 'C', isCorrect: false },
            { id: 'd', text: 'D', isCorrect: false }
          ],
          explanation: '85 >= 80, so "Grade: B" is printed. The program checks conditions in order and stops at the first true one.',
          hint: '85 is less than 90 but greater than or equal to 80.'
        }
      },
      {
        id: 'step-8-5',
        type: 'code-execute',
        order: 5,
        content: {
          title: 'Practice: Write a Conditional',
          text: 'Write code that prints "Even" if a number is even, "Odd" if odd:',
          starterCode: 'number = 7\n\n# Write your conditional here\n# Hint: use % operator (modulo)',
          language: 'python',
          expectedOutput: 'Odd'
        }
      }
    ]
  },
  {
    id: 'lesson-9',
    courseId: 'science-basics',
    title: 'The Scientific Method',
    description: 'Learn how scientists solve problems',
    order: 1,
    xpReward: 100,
    estimatedMinutes: 10,
    isPublished: true,
    steps: [
      {
        id: 'step-9-1',
        type: 'text',
        order: 1,
        content: {
          title: 'What is Science?',
          text: 'Science is a systematic way of understanding the natural world through observation, experimentation, and logical reasoning.'
        }
      },
      {
        id: 'step-9-2',
        type: 'sorting',
        order: 2,
        content: {
          title: 'Steps of the Scientific Method',
          text: 'Arrange the steps in the correct order:',
          sortItems: [
            { id: 's1', content: 'Ask a Question', correctPosition: 1 },
            { id: 's2', content: 'Do Background Research', correctPosition: 2 },
            { id: 's3', content: 'Construct a Hypothesis', correctPosition: 3 },
            { id: 's4', content: 'Test with Experiment', correctPosition: 4 },
            { id: 's5', content: 'Analyze Results', correctPosition: 5 },
            { id: 's6', content: 'Draw Conclusion', correctPosition: 6 }
          ],
          correctOrder: ['s1', 's2', 's3', 's4', 's5', 's6']
        }
      },
      {
        id: 'step-9-3',
        type: 'multiple-choice',
        order: 3,
        content: {
          question: 'What is a hypothesis?',
          options: [
            { id: 'a', text: 'A proven fact', isCorrect: false },
            { id: 'b', text: 'An educated guess to test', isCorrect: true },
            { id: 'c', text: 'The final answer', isCorrect: false },
            { id: 'd', text: 'An experiment result', isCorrect: false }
          ],
          explanation: 'A hypothesis is a testable prediction - an educated guess about what will happen in an experiment.',
          hint: 'Hypotheses are tested, not proven immediately.'
        }
      }
    ]
  },
  {
    id: 'lesson-10',
    courseId: 'science-basics',
    title: 'Simple Circuits',
    description: 'Understand how electric circuits work',
    order: 2,
    xpReward: 100,
    estimatedMinutes: 15,
    isPublished: true,
    steps: [
      {
        id: 'step-10-1',
        type: 'text',
        order: 1,
        content: {
          title: 'What is a Circuit?',
          text: 'A circuit is a path that electricity flows through. It needs a power source (battery), conductors (wires), and often a load (like a light bulb).'
        }
      },
      {
        id: 'step-10-2',
        type: 'simulation',
        order: 2,
        content: {
          title: 'Build a Circuit',
          text: 'Click to add components and build a simple circuit:',
          simulationType: 'circuit',
          simulationConfig: {
            components: [
              { id: 'bat', type: 'battery', x: 50, y: 100, value: 9 },
              { id: 'led', type: 'led', x: 200, y: 100 }
            ]
          }
        }
      },
      {
        id: 'step-10-3',
        type: 'multiple-choice',
        order: 3,
        content: {
          question: 'What happens if you break a wire in a circuit?',
          options: [
            { id: 'a', text: 'Nothing changes', isCorrect: false },
            { id: 'b', text: 'Current keeps flowing', isCorrect: false },
            { id: 'c', text: 'Current stops flowing (open circuit)', isCorrect: true },
            { id: 'd', text: 'Battery explodes', isCorrect: false }
          ],
          explanation: 'A break in the circuit creates an "open circuit" - electricity cannot flow because the path is incomplete.',
          hint: 'Electricity needs a complete loop to flow.'
        }
      },
      {
        id: 'step-10-4',
        type: 'drag-drop',
        order: 4,
        content: {
          title: 'Match Circuit Symbols',
          text: 'Drag each component name to its symbol:',
          dragItems: [
            { id: 'd1', content: 'Battery', type: 'text', correctZone: 'z1' },
            { id: 'd2', content: 'Resistor', type: 'text', correctZone: 'z2' },
            { id: 'd3', content: 'Switch', type: 'text', correctZone: 'z3' }
          ],
          dropZones: [
            { id: 'z1', label: '⚡ ─| |─' },
            { id: 'z2', label: '╱╱╱╱' },
            { id: 'z3', label: '─○/○─' }
          ]
        }
      }
    ]
  }
]

export function DataProvider({ children }: { children: ReactNode }) {
  // TV App State
  const [settings, setSettings] = useState<Settings | null>(null)
  const [slides, setSlides] = useState<Slide[]>([])
  const [videos, setVideos] = useState<Video[]>([])
  const [prayerRequests, setPrayerRequests] = useState<PrayerRequest[]>([])
  const [testimonies, setTestimonies] = useState<Testimony[]>([])
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loading, setLoading] = useState(true)
  
  // Learning State
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [courses] = useState<Course[]>(defaultCourses)
  const [lessons] = useState<Lesson[]>(defaultLessons)
  const [userProgress, setUserProgress] = useState<LessonProgress[]>([])
  const [badges] = useState<Badge[]>(defaultBadges)
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])

  useEffect(() => {
    const loadData = () => {
      // TV Settings
      const defaultSettings: Settings = {
        site_name: 'TRUMPETER TV',
        slider_interval: 6000,
        youtube_live_url: '',
        facebook_live_url: '',
        tv_program_queue: []
      }

      const defaultSlides: Slide[] = [
        { id: '1', imageUrl: 'https://images.unsplash.com/photo-1507692049790-de58290a4334?w=1920&q=80', title: 'Welcome to TRUMPETER TV' },
        { id: '2', imageUrl: 'https://images.unsplash.com/photo-1438232992991-995b7058bbb3?w=1920&q=80', title: 'Join Us Live' },
        { id: '3', imageUrl: 'https://images.unsplash.com/photo-1504052434569-70ad5836ab65?w=1920&q=80', title: 'Worship With Us' },
      ]

      const defaultVideos: Video[] = []

      // Load from localStorage
      const savedSettings = localStorage.getItem('trumpeter_settings')
      const savedSlides = localStorage.getItem('trumpeter_slides')
      const savedVideos = localStorage.getItem('trumpeter_videos')
      const savedPrayerRequests = localStorage.getItem('trumpeter_prayer_requests')
      const savedTestimonies = localStorage.getItem('trumpeter_testimonies')
      const savedLogin = localStorage.getItem('trumpeter_logged_in')
      const savedUser = localStorage.getItem('trumpeter_user')
      const savedProgress = localStorage.getItem('trumpeter_progress')

      setSettings(savedSettings ? JSON.parse(savedSettings) : defaultSettings)
      setSlides(savedSlides ? JSON.parse(savedSlides) : defaultSlides)
      setVideos(savedVideos ? JSON.parse(savedVideos) : defaultVideos)
      setPrayerRequests(savedPrayerRequests ? JSON.parse(savedPrayerRequests) : [])
      setTestimonies(savedTestimonies ? JSON.parse(savedTestimonies) : [])
      setIsLoggedIn(savedLogin === 'true')
      
      if (savedUser) setCurrentUser(JSON.parse(savedUser))
      if (savedProgress) setUserProgress(JSON.parse(savedProgress))
      
      setLoading(false)
    }

    loadData()
  }, [])

  // Update leaderboard when user changes
  useEffect(() => {
    if (currentUser) {
      setLeaderboard([
        { userId: currentUser.id, userName: currentUser.name, xp: currentUser.xp, streak: currentUser.streak, level: currentUser.level, rank: 1 },
        { userId: 'demo1', userName: 'Sarah M.', xp: 4500, streak: 12, level: 8, rank: 2 },
        { userId: 'demo2', userName: 'John D.', xp: 3200, streak: 7, level: 6, rank: 3 },
        { userId: 'demo3', userName: 'Grace K.', xp: 2800, streak: 5, level: 5, rank: 4 },
        { userId: 'demo4', userName: 'Peter A.', xp: 1500, streak: 3, level: 3, rank: 5 },
      ])
    }
  }, [currentUser])

  // TV App Functions
  const updateSettings = (newSettings: Partial<Settings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings } as Settings
      localStorage.setItem('trumpeter_settings', JSON.stringify(updated))
      return updated
    })
  }

  const addSlide = (slide: Slide) => {
    setSlides(prev => {
      const updated = [...prev, slide]
      localStorage.setItem('trumpeter_slides', JSON.stringify(updated))
      return updated
    })
  }

  const removeSlide = (id: string) => {
    setSlides(prev => {
      const updated = prev.filter(s => s.id !== id)
      localStorage.setItem('trumpeter_slides', JSON.stringify(updated))
      return updated
    })
  }

  const addVideo = (video: Video) => {
    setVideos(prev => {
      const updated = [...prev, video]
      localStorage.setItem('trumpeter_videos', JSON.stringify(updated))
      return updated
    })
  }

  const removeVideo = (id: string) => {
    setVideos(prev => {
      const updated = prev.filter(v => v.id !== id)
      localStorage.setItem('trumpeter_videos', JSON.stringify(updated))
      return updated
    })
  }

  const login = (email: string, password: string): boolean => {
    if (email.toLowerCase() === LOGIN_EMAIL.toLowerCase() && password === LOGIN_PASSWORD) {
      setIsLoggedIn(true)
      localStorage.setItem('trumpeter_logged_in', 'true')
      
      // Create user if not exists
      const savedUser = localStorage.getItem('trumpeter_user')
      if (!savedUser) {
        const newUser: User = {
          id: `user-${Date.now()}`,
          name: 'Admin',
          email: email,
          xp: 0,
          streak: 0,
          longestStreak: 0,
          level: 1,
          badges: [],
          completedLessons: [],
          completedCourses: [],
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString()
        }
        setCurrentUser(newUser)
        localStorage.setItem('trumpeter_user', JSON.stringify(newUser))
      }
      
      return true
    }
    return false
  }

  const logout = () => {
    setIsLoggedIn(false)
    localStorage.removeItem('trumpeter_logged_in')
  }

  const addPrayerRequest = (requestData: Omit<PrayerRequest, 'id' | 'createdAt'>) => {
    const newRequest: PrayerRequest = {
      ...requestData,
      id: `prayer-${Date.now()}`,
      createdAt: new Date().toISOString()
    }
    setPrayerRequests(prev => {
      const updated = [newRequest, ...prev]
      localStorage.setItem('trumpeter_prayer_requests', JSON.stringify(updated))
      return updated
    })
  }

  const addTestimony = (testimonyData: Omit<Testimony, 'id' | 'createdAt'>) => {
    const newTestimony: Testimony = {
      ...testimonyData,
      id: `testimony-${Date.now()}`,
      createdAt: new Date().toISOString()
    }
    setTestimonies(prev => {
      const updated = [newTestimony, ...prev]
      localStorage.setItem('trumpeter_testimonies', JSON.stringify(updated))
      return updated
    })
  }

  // Learning Functions
  const startLesson = (lessonId: string) => {
    if (!currentUser) return
    
    const existingProgress = userProgress.find(p => p.lessonId === lessonId)
    if (existingProgress) return
    
    const newProgress: LessonProgress = {
      lessonId,
      userId: currentUser.id,
      status: 'in-progress',
      currentStep: 0,
      completedSteps: [],
      xpEarned: 0,
      timeSpent: 0,
      attempts: 0,
      startedAt: new Date().toISOString()
    }
    
    setUserProgress(prev => {
      const updated = [...prev, newProgress]
      localStorage.setItem('trumpeter_progress', JSON.stringify(updated))
      return updated
    })
  }

  const completeStep = (lessonId: string, stepId: string, isCorrect: boolean) => {
    if (!currentUser) return
    
    setUserProgress(prev => {
      const updated = prev.map(p => {
        if (p.lessonId === lessonId) {
          return {
            ...p,
            completedSteps: [...p.completedSteps, stepId],
            currentStep: p.currentStep + 1,
            xpEarned: isCorrect ? p.xpEarned + 10 : p.xpEarned
          }
        }
        return p
      })
      localStorage.setItem('trumpeter_progress', JSON.stringify(updated))
      return updated
    })
    
    if (isCorrect) {
      addXP(10)
    }
  }

  const completeLesson = (lessonId: string) => {
    if (!currentUser) return
    
    const lesson = lessons.find(l => l.id === lessonId)
    if (!lesson) return
    
    setUserProgress(prev => {
      const updated = prev.map(p => {
        if (p.lessonId === lessonId) {
          return {
            ...p,
            status: 'completed' as const,
            completedAt: new Date().toISOString(),
            xpEarned: p.xpEarned + lesson.xpReward
          }
        }
        return p
      })
      localStorage.setItem('trumpeter_progress', JSON.stringify(updated))
      return updated
    })
    
    // Add XP and update user
    addXP(lesson.xpReward)
    
    setCurrentUser(prev => {
      if (!prev) return prev
      const updated = {
        ...prev,
        completedLessons: [...prev.completedLessons, lessonId],
        lastActive: new Date().toISOString()
      }
      localStorage.setItem('trumpeter_user', JSON.stringify(updated))
      return updated
    })
    
    updateStreak()
  }

  const getUserXP = () => currentUser?.xp || 0
  const getUserLevel = () => currentUser?.level || 1
  const getStreak = () => currentUser?.streak || 0

  const getLessonProgress = (lessonId: string) => {
    return userProgress.find(p => p.lessonId === lessonId)
  }

  const getCourseProgress = (courseId: string) => {
    const course = courses.find(c => c.id === courseId)
    if (!course || !currentUser) return 0
    
    const completed = course.lessons.filter(l => 
      currentUser.completedLessons.includes(l)
    ).length
    
    return Math.round((completed / course.lessons.length) * 100)
  }

  const addXP = (amount: number) => {
    setCurrentUser(prev => {
      if (!prev) return prev
      const newXP = prev.xp + amount
      const newLevel = Math.floor(newXP / 500) + 1
      const updated = { ...prev, xp: newXP, level: newLevel }
      localStorage.setItem('trumpeter_user', JSON.stringify(updated))
      return updated
    })
  }

  const updateStreak = () => {
    setCurrentUser(prev => {
      if (!prev) return prev
      const lastActive = new Date(prev.lastActive).toDateString()
      const today = new Date().toDateString()
      const yesterday = new Date(Date.now() - 86400000).toDateString()
      
      let newStreak = prev.streak
      if (lastActive === yesterday) {
        newStreak = prev.streak + 1
      } else if (lastActive !== today) {
        newStreak = 1
      }
      
      const updated = {
        ...prev,
        streak: newStreak,
        longestStreak: Math.max(prev.longestStreak, newStreak),
        lastActive: new Date().toISOString()
      }
      localStorage.setItem('trumpeter_user', JSON.stringify(updated))
      return updated
    })
  }

  const awardBadge = (badgeId: string) => {
    setCurrentUser(prev => {
      if (!prev || prev.badges.includes(badgeId)) return prev
      const badge = badges.find(b => b.id === badgeId)
      if (!badge) return prev
      
      const updated = {
        ...prev,
        badges: [...prev.badges, badgeId],
        xp: prev.xp + badge.xpReward
      }
      localStorage.setItem('trumpeter_user', JSON.stringify(updated))
      return updated
    })
  }

  return (
    <DataContext.Provider value={{
      // TV
      settings, slides, videos, prayerRequests, testimonies, isLoggedIn, loading,
      updateSettings, addSlide, removeSlide, addVideo, removeVideo,
      login, logout, addPrayerRequest, addTestimony,
      // Learning
      currentUser, courses, lessons, userProgress, badges, leaderboard,
      startLesson, completeStep, completeLesson,
      getUserXP, getUserLevel, getStreak, getLessonProgress, getCourseProgress,
      addXP, updateStreak, awardBadge
    }}>
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider')
  }
  return context
}
